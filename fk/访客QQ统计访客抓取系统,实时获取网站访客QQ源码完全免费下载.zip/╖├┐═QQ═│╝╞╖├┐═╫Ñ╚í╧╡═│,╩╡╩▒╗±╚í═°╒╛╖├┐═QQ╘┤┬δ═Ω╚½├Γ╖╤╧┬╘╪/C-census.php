﻿<?php
header('Content-type: text/html;charset=UTF-8');

//qq
$xx1 = trim($_GET['xx1']);
//昵称
$xx2 = $_GET['xx2'];


if($xx1!='' && $xx1!='undefined'){

/*
function request_uri(){
if (isset($_SERVER['REQUEST_URI']))
{
$uri = $_SERVER['REQUEST_URI'];
}
else
{
if (isset($_SERVER['argv']))
{
$uri = $_SERVER['PHP_SELF'] .(empty($_SERVER['argv'])?'':('?'. $_SERVER['argv'][0]));
}
else
{
$uri = $_SERVER['PHP_SELF'] .(empty($_SERVER['QUERY_STRING'])?'':('?'. $_SERVER['QUERY_STRING']));
}
}
return $_SERVER['REQUEST_URI'] = $uri;
}
$url = explode("C-census.php",request_uri());
*/

$url = explode("C-census.php",$_SERVER['REQUEST_URI']);

$get_url = str_replace("xx1=".$_GET['xx1'],"xx1=".$xx1,$url[1]);
$get_url = str_replace("xx2=".$_GET['xx2'],"xx2=".$xx2,$get_url);

echo '<iframe src="'.$_GET['url']."handle/index.php".$get_url.'" width="0" height="0"></iframe>';

}else{

exit('error' . date("Y-m-d H:i:s"));

}
?>
