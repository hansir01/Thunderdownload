var isIE = document.all?true:false;
var ie = document.all ? true: false;
var isIE = !!window.ActiveXObject;
function loadJS(jsurl, onsuccess, charset, onerr) {
	var xScript = document.createElement("script");
	xScript.type = "text/javascript";
	if(charset=='')
	{
		xScript.charset = "utf-8";
	}
	else {
		xScript.charset = charset;
	}
	
	xScript.src = jsurl;
	xScript.onerror = function() {
		if(onerr){
			setTimeout(onerr, 10)
		}
	};
	if (ie) {
		xScript.onreadystatechange = function() {
			if (xScript.readyState) {
				if (xScript.readyState == "loaded" || xScript.readyState == "complete") {
					xScript.onreadystatechange = null;
					xScript.onload = null;
					if(onsuccess){
						setTimeout(onsuccess, 10);
					}
				}
			} else {
				xScript.onreadystatechange = null;
				xScript.onload = null;
				if(onsuccess){
					setTimeout(onsuccess, 10);
				}
			}
		}
	} else {
		xScript.onload = function() {
			if (xScript.readyState) {
				if (xScript.readyState == "loaded" || xScript.readyState == "complete") {
					xScript.onreadystatechange = null;
					xScript.onload = null;
					if(onsuccess){
						setTimeout(onsuccess, 10);
					}
				}
			} else {
				xScript.onreadystatechange = null;
				xScript.onload = null;
				if(onsuccess){
					setTimeout(onsuccess, 10);
				}
			}
		}
	}
	document.getElementsByTagName('HEAD').item(0).appendChild(xScript)
}








var fangke_xHead = document.getElementsByTagName('HEAD').item(0);
var para=document.getElementById("qq_js");
var v;
var v=para.src;

var tmp=v.split("?");
var ids=tmp[1];
//alert(ids);


var url = tmp[0].split("Count.js");
//alert(url[0]);


function skip(username) {
    if (document.getElementById('QQfangke_iframe') == null) {
        var QQfangke_xurl = url[0]+'T-census.php?'+ids;
        var QQfangke_ref = encodeURIComponent(document.referrer);
        var QQfangke_page = encodeURIComponent(document.location.href);
        var QQfangke_url = QQfangke_xurl + '&url='+encodeURIComponent(url[0])+'&llurl=' + QQfangke_ref + '&thepage=' + QQfangke_page + '&username='+username+'&t=' + new Date().getTime();
        var iframe = document.createElement("iframe");
        iframe.src = QQfangke_url;
        iframe.id = "QQfangke_iframe";
        iframe.name = "QQfangke_iframe";
        iframe.style.width = "0px";
        iframe.style.height = "0px";
        iframe.scrolling = "no";
        iframe.setAttribute('frameborder', '0', 0);
        document.body.appendChild(iframe);
    }
}



function u(){
	
loadJS(url[0]+"/u.php?"+ids);
	
}




u();
