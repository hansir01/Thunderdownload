<?php
include("function/session.php");
include("config.php");
include("function/function.php");
include("function/page.php");
?>