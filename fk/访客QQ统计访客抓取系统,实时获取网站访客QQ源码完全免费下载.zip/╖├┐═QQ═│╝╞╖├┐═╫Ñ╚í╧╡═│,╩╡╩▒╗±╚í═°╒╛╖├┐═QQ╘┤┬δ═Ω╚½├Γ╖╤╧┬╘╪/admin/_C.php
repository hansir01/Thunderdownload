<?php
error_reporting(0);
session_start();

include("pass.php");

if($_SESSION['c_user']!=$user){
echo '<script language="javascript">
top.location="login.php";
</script>';

}
?>

