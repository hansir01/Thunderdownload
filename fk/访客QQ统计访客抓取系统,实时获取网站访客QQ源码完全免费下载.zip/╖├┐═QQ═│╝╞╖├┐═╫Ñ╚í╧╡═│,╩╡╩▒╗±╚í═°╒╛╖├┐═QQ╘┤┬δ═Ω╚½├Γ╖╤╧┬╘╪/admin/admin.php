<?php
include("_C.php");
include("../config.php");
include("../function/page.php");
include("function.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" />
<script type="text/javascript" src="../js/jquery-1.9.0.min.js"></script>
</head>

<body>


<table cellpadding="0" cellspacing="0" border="0" width="100%">
<tr>
<td width="8%" valign="top">



<?php include("left.php");?>

</td>




<td width="92%" valign="top">

<table cellpadding="0" cellspacing="1" bgcolor="#333333" class="tables" style="width:1050px;">
 
  <tr>
    <td colspan="12">
	
	<form name="myform" method="post" action="" onSubmit="return Form_Submit()">
	<table cellpadding="0" cellspacing="0" border="0">
	
	<tr>
	<td>后台账号：</td><td><input name="user" id="user" type="text" value="<?php echo $user;?>" style="width:150px;" /> </td>
	</tr>
	<tr>
	<td>后台密码：</td><td><input name="pass" id="pass" type="text" value="<?php echo $pass;?>" style="width:150px;" /></td>
	</tr>
	<tr>
	<td></td><td><input name="submit" type="submit" value="添加" /></td>
	</tr>
	</table>
</form>


	</td>

  </tr>

</table>


</td>
</tr>
</table>


<?php

if($_POST['submit']){
$user = trim($_POST['user']);
$pass = trim($_POST['pass']);


$fp=fopen("pass.php","w+");//fopen()的其它开关请参看相关函数
$str.="<?php
";
$str.= '$user= "'.$user.'";';

$str.= '$pass= "'.$pass.'";';
$str.="
?>";
fputs($fp,$str);
fclose($fp);

echo '<script>
alert("操作成功.");
window.location.href="admin.php";
</script>';
exit();


}
?>


 <script type="text/javascript">
function Form_Submit(){

	
	if(document.getElementById("user").value==""){
		alert("后台账号不能为空.");
		return false;
	}
	
	if(document.getElementById("pass").value==""){
		alert("后台密码不能为空.");
		return false;
	}
	


} 

</script>

</body>
</html>
