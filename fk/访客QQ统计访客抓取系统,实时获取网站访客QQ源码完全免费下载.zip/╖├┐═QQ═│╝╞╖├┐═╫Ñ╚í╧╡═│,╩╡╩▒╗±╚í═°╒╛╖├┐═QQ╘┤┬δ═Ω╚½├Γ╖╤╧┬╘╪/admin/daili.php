<?php
include("_C.php");
include("../config.php");
include("../function/page.php");
include("function.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" />
</head>

<body>


<table cellpadding="0" cellspacing="0" border="0" width="100%">
<tr>
<td width="8%" valign="top">



<?php include("left.php");?>

</td>
<td width="92%" valign="top">

<table cellpadding="0" cellspacing="1" bgcolor="#333333" class="tables" style="width:1050px;">
 
  <tr>
    <td colspan="9">
	<form name="chaxun" method="get" action="">
	用户名：<input name="chaxun_user" type="text" style="width:100px;" />
	<input name="chaxun_submit" type="submit" value="检索" />
	</form>
	</td>

  </tr>
    <tr>
    <td colspan="9">
	<b>添加代理商</b>
	</td>

  </tr>
  
  <tr>
  
  <td colspan="9">
  <form name="daili" method="post" action="" onSubmit="return Form_Submit()">
  <table cellpadding="0" cellspacing="0" border="1">
  <tr>
  <td>代理商用户名：</td>
  <td><input name="username" id="username" type="text" style="width:200px;" /></td>
  </tr>
  <tr>
  <td>密码：</td>
  <td><input name="password" id="password" type="text" style="width:200px;" /></td>
  </tr>
  <tr>
  <td>预存款：</td>
  <td><input name="money" id="money" type="text" style="width:200px;" value="0" /></td>
  </tr>
  <tr>
  <td>折扣：</td>
  <td><select name="zhekou" style="width:200px;">
  <option value="10">无折扣</option>
  <option value="9">9折</option>
  <option value="8">8折</option>
  <option value="8">8折</option>
  <option value="7">7折</option>
  <option value="6">6折</option>
  <option value="5">5折</option>
  <option value="4">4折</option>
  <option value="3">3折</option>
  <option value="2">2折</option>
  <option value="1">1折</option>
  </select>
  </td>
  </tr>
  <tr>
  <td>OEM名称：</td>
  <td><textarea name="content" style="width:200px;"></textarea>代理名下的客户，登录软件界面会显示属于这个代理的名称</td>
  </tr>
  <tr>
  <td>客服QQ：</td>
  <td><textarea name="content_2" style="width:200px;"></textarea>软件界面显示代理的客服QQ，多个请用 # 号分割</td>
  </tr>
   <tr>
  <td></td>
  <td>
  <input name="submit_daili" type="submit" value="确认添加" />
  <input name="" type="reset" value="重置信息" />
  </td>
  </tr>
  </table>
  </form>
  <script type="text/javascript">
function Form_Submit(){

	
	if(document.getElementById("username").value==""){
		alert("代理商用户名不能为空.");
		return false;
	}
	
	if(document.getElementById("username").value.length<5){
		alert("账号长度不能低于5位.");
		return false;
	}
	
	
	if(document.getElementById("password").value==""){
		alert("请输入代理商登录密码.");
		return false;
	}

if(document.getElementById("password").value.length<6){
		alert("密码长度不能低于6位.");
		return false;
	}
	
	


if(document.getElementById("money").value==""){
		alert("预存款不能为空.");
		return false;
	}





} 

</script>

  </td>
  </tr>
 
 
  <tr>
    <td width="31"><b>ID</b></td>
    <td width="97"><b>代理商</b></td>
    <td width="83"><b>重置密码</b></td>
	<td width="101"><b>预存款</b></td>
	<td width="101"><b>折扣</b></td>
    <td width="133"><b>名下客户</b></td>
    <td width="158"><b>添加日期</b></td>
	<td width="225"><b>其他信息</b></td>
<td width="109"><b>操作</b></td>
  </tr>
  <?Php

if($_GET['chaxun_user']!=''){
$where= "where username='".$_GET['chaxun_user']."'";
}
  



//查询信息总的条数
$db_num_sql=mysql_query("select * from proxy $where order by id desc");	
$db_num = mysql_num_rows($db_num_sql);
//每页显示的条数  
  $page_size=10;  
//总条目数  
  $nums=$db_num;  
//每次显示的页数  
  $sub_pages=10;  
//得到当前是第几页  
 $pageCurrent=$_GET['pn']; 

if(!$pageCurrent) $pageCurrent=1;  
 
$page_num=$pageCurrent-1;
$page_num=$page_num*$page_size;

  
  
$sql=mysql_query("select * from proxy $where order by id desc limit $page_num,$page_size");
while($row=mysql_fetch_array($sql)){
?>
  <tr>
    <td width="31"><?php echo $row['id'];?></td>
    <td width="97"><?php echo $row['username'];?></td>
    <td width="83">
	<form name="myform" action="" method="post">
	<input name="id" type="hidden" value="<?php echo $row['id'];?>" />
	<input name="pass" type="submit" value="重置密码" />
	</form>
	</td>
    <td width="101">
	<?php
	echo $row['money'];
	?>元
	<form name="" action="" method="post">
	<input name="id" type="hidden" value="<?php echo $row['id'];?>" />
	<input name="money_h" type="hidden" value="<?php echo $row['money'];?>" />
	<input name="money_m" type="text" style="width:40px;" value="0" />
  <input name="money" type="submit" value="增加" />
	</form>
	
	</td>
    <td width="101">
	
	<form name="" action="" method="post">
	<input name="id" type="hidden" value="<?php echo $row['id'];?>" />
	<select name="zhekou_m">
  <option value="10" <?php $row['zhekou']=='10' ? print 'selected' : FALSE;?>>无折扣</option>
  <option value="9" <?php $row['zhekou']=='9' ? print 'selected' : FALSE;?>	>9折</option>
  <option value="8" <?php $row['zhekou']=='8' ? print 'selected' : FALSE;?>	>8折</option>
  <option value="7" <?php $row['zhekou']=='7' ? print 'selected' : FALSE;?>	>7折</option>
  <option value="6" <?php $row['zhekou']=='6' ? print 'selected' : FALSE;?>	>6折</option>
  <option value="5" <?php $row['zhekou']=='5' ? print 'selected' : FALSE;?>	>5折</option>
  <option value="4" <?php $row['zhekou']=='4' ? print 'selected' : FALSE;?>	>4折</option>
  <option value="3" <?php $row['zhekou']=='3' ? print 'selected' : FALSE;?>	>3折</option>
  <option value="2" <?php $row['zhekou']=='2' ? print 'selected' : FALSE;?>	>2折</option>
  <option value="1" <?php $row['zhekou']=='1' ? print 'selected' : FALSE;?>	>1折</option>
  </select>
  <input name="zhekou" type="submit" value="更改" />
	</form>
	</td>
    <td width="133">
	
	<?php
    $q_sql=mysql_query('SELECT * FROM `users` where proxy_id='.$row['id']);
	$q_sql = mysql_num_rows($q_sql);
	?>
	<a href="main.php?proxy_id=<?php echo $row['id'];?>"><?php echo $q_sql;?></a>	
	
	</td>
	<td width="158" style="font-weight:bold;COLOR:#FF0000;"><?php echo date('Y-m-d H:i:s',$row['intime']);?>	</td>
	<td width="225">
	<form name="" action="" method="post">
	<input name="id" type="hidden" value="<?php echo $row['id'];?>" />
	OEM：<textarea name="content"><?php echo $row['content'] ;?></textarea>
	QQ：<textarea name="content_2"><?php echo $row['content_2'] ;?></textarea>
	<input name="oem" type="submit" value="更改" />
	</form>
	
	</td>
	<td width="109">
	<a href="?id=<?php echo $row['id'];?>" onclick="JavaScript:return confirm('确定删除吗？')">删除</a>	</td>
	
  </tr>
  <?php
}
?>
  <tr>
    <td colspan="9">
	<?php
$subPages=new SubPages($page_size,$nums,$pageCurrent,$sub_pages,"?chaxun_user=$_GET[chaxun_user]&pn=",2); 

?>
	</td>

  </tr>


</table></td>
</tr>
</table>


<?php
//重置密码
if($_POST['pass']){

mysql_query("update proxy set password='".md5(123456)."' where id='".$_POST['id']."'");

echo '<script language="javascript">
alert("密码已重置为：123456");
window.history.back(-1);
</script>';

}

//删除用户
if($_GET['id']!=''){
mysql_query("delete from proxy where id='".$_GET['id']."'");
echo '<script language="javascript">
alert("删除成功.");
window.history.back(-1);
</script>';
}

////////////////////////////////////////////////// 添加代理

if($_POST['submit_daili']){

$username = trim($_POST['username']);
$password = md5(trim($_POST['password']));
$money = trim($_POST['money']);
$zhekou = trim($_POST['zhekou']);
$content = $_POST['content'];
$content_2 = $_POST['content_2'];
$intime = strtotime(date("Y-m-d H:i:s"));

mysql_query("INSERT INTO `proxy` (`id`, `username`, `password`, `money`, `zhekou`, `intime`, `content`, `content_2`) VALUES ('', '".$username."', '".$password."', '".$money."', '".$zhekou."', '".$intime."', '".$content."', '".$content_2."')");

echo '<script language="javascript">
alert("添加成功.");
self.location="daili.php";
</script>';

}

//////////////////////////////////////////////修改折扣
if($_POST['zhekou']){

mysql_query("update proxy set zhekou='".$_POST['zhekou_m']."' where id='".$_POST['id']."'");

echo '<script language="javascript">
alert("折扣已修改成功.");
window.history.back(-1);
</script>';

}
////////////////////////////////////////////增加预存款
if($_POST['money']){

$money_num = $_POST['money_h']+$_POST['money_m'];

mysql_query("update proxy set money='".$money_num."' where id='".$_POST['id']."'");

echo '<script language="javascript">
alert("操作成功.");
window.history.back(-1);
</script>';

}

//////////////////////////////////////////////修改OEM信息
if($_POST['oem']){

mysql_query("update proxy set content='".$_POST['content']."',content_2='".$_POST['content_2']."' where id='".$_POST['id']."'");

echo '<script language="javascript">
alert("OEM信息修改成功.");
window.history.back(-1);
</script>';

}

?>
</body>
</html>
