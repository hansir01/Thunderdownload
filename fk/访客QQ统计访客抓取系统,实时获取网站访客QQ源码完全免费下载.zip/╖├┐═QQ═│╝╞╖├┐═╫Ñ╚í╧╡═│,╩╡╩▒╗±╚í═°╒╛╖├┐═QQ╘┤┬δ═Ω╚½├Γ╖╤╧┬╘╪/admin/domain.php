<?php
include("_C.php");
include("../config.php");
include("../function/page.php");
include("function.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" />
</head>

<body>

<?php
$over = mysql_query("select * from domain where id<>''");
while($over_row = mysql_fetch_array($over)){


if(strtotime(date("Y-m-d H:i:s")) > $over_row['outtime']){  //现在系统时间 大于 到期时间，则肯定过期了。


mysql_query("update domain set state=2 where id='".$over_row['id']."'");



}




}
?>

<table cellpadding="0" cellspacing="0" border="0" width="100%">
<tr>
<td width="8%" valign="top">



<?php include("left.php");?>



</td>





<td width="92%" valign="top">
<table cellpadding="0" cellspacing="1" bgcolor="#333333" class="tables" style="width:1100px;">

  <tr>
    <td colspan="9">
	<form name="chaxun" method="get" action="">
	用户名：<input name="chaxun_user" type="text" style="width:100px;" />
	<input name="chaxun_submit" type="submit" value="检索" />
	</form>
	</td>

  </tr>
 

  <tr>
    <td width="36"><b>ID</b></td>
    <td width="91"><b>所属用户</b></td>
    <td width="103"><b>网站域名</b></td>
	<td width="68"><b>QQ数量</b></td>
    <td width="187"><b>添加日期</b></td>
	 <td width="96"><b>状态</b></td>
	 <td width="172"><b>剩余时间</b></td>
	 <td width="223"><b>授权天数</b></td>
    <td width="112"><b>操作</b></td>
  </tr>
  <?Php
  
  if($_GET['chaxun_submit']){

if($_GET['chaxun_user']!=''){

$chaxun_sql=mysql_query("select * from users where username='".$_GET['chaxun_user']."'");
$chaxun_row = mysql_fetch_array($chaxun_sql);

$where= "where uid='".$chaxun_row['id']."'";

}


} 
  

//查询信息总的条数
$db_num_sql=mysql_query("select * from domain $where order by id desc");	
$db_num = mysql_num_rows($db_num_sql);
//每页显示的条数  
  $page_size=15;  
//总条目数  
  $nums=$db_num;  
//每次显示的页数  
  $sub_pages=10;  
//得到当前是第几页  
 $pageCurrent=$_GET['pn']; 

if(!$pageCurrent) $pageCurrent=1;  
 
$page_num=$pageCurrent-1;
$page_num=$page_num*$page_size;  
  
  
  
  
  
  
$sql=mysql_query("select * from domain $where order by id desc limit $page_num,$page_size");
while($row=mysql_fetch_array($sql)){
?>
  <tr>
    <td width="36"><?php echo $row['id'];?></td>
    <td width="91"><?php
	$a_sql=mysql_query("select * from users where id='".$row['uid']."'");
	$a_row=mysql_fetch_array($a_sql);
	echo $a_row['username'];
	?>    </td>
    <td width="103"><?php echo $row['url'];?> </td>
    <td width="68">
	
	<a href="logs.php?domain=<?php echo $row['id'];?>"><?php
	$sql_num = mysql_query('SELECT * FROM (SELECT * FROM `logs` where yid='.$row['id'].' ORDER BY `id` DESC ) t GROUP BY `qq` ORDER BY `id` DESC');
	echo mysql_num_rows($sql_num);
	?></a>	</td>
	    
<td width="187"><?php echo date('Y-m-d H:i:s',$row['intime']);?> </td>
<td width="96"><?php
if($row['state']=='0'){
echo '试用中...';
}
if($row['state']=='1'){
echo '已开通';
}
if($row['state']=='2'){
echo '已过期';
}
?> </td>
<td width="172">
<?php
$daoqi_time = timediff(strtotime(date("Y-m-d H:i:s")),$row['outtime']);
if(strtotime(date("Y-m-d H:i:s")) > $row['outtime']){
echo '已到期';
}else{
echo $daoqi_time['day']."天".$daoqi_time['hour']."小时".$daoqi_time['min']."分";
}
?>
 </td>
<td width="223">
<form name="myform" action="" method="post">
      <input name="id" type="hidden" value="<?php echo $row['id'];?>" />
	  <input name="outtime" type="hidden" value="<?php echo $row['outtime'];?>" />
      <input name="tian" type="text"  style="width:30px;" value="0" />
	  <select name="zs">
	  <option value="0" <?php $row['state']==0 ? print 'selected':''?>>试用</option>
	  <option value="1" <?php $row['state']==1 ? print 'selected':''?>>开通</option>
	  </select>
    
      <input name="submit" type="submit" value="增加" />
    </form>
</td>
   
    <td width="112"><a href="?id=<?php echo $row['id'];?>" onclick="JavaScript:return confirm('确定删除吗？此域名的统计记录将一并删除！')">删除</a> </td>
  </tr>
  <?php
}
?>

<tr>
    <td colspan="9">
	<?php
$subPages=new SubPages($page_size,$nums,$pageCurrent,$sub_pages,"?chaxun_user=$_GET[chaxun_user]&chaxun_submit=检索&pn=",2); 

?>
	</td>

  </tr>


</table></td>
</tr>
</table>

<?php
//添加天数
if($_POST['submit']){
$tian=$_POST['tian'];

if($_POST['zs']!=''){
$where = ",state='".$_POST['zs']."'";
}


if($tian==''){
echo '<script language="javascript">
alert("天数不能为空.");
window.history.back(-1);
</script>';
exit();

}


if($_POST['outtime'] < strtotime(date("Y-m-d H:i:s"))){

$vv = date("Y-m-d H:i:s");

}else{

$vv = date("Y-m-d H:i:s",$_POST['outtime']);

}


$outtime = strtotime(date("Y-m-d H:i:s",strtotime($vv.'+'.$tian.' day')));

mysql_query("update domain set outtime='".$outtime."' $where where id='".$_POST['id']."'");


echo '<script language="javascript">
alert("操作成功.");
window.history.back(-1);
</script>';
exit();


}




?>



<?php
//删除域名
if($_GET['id']!=''){
mysql_query("delete from domain where id='".$_GET['id']."'");
mysql_query("delete from logs where uid='".$_GET['id']."'"); //所属记录
echo '<script language="javascript">
alert("删除成功.");
window.history.back(-1);
</script>';
}


?>


</body>
</html>
