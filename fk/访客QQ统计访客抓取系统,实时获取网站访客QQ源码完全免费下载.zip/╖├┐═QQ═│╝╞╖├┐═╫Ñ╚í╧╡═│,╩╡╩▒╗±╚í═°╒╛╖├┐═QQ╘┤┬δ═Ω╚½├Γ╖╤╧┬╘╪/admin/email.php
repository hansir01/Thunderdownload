<?php
include("_C.php");
include("../config.php");
include("../function/page.php");
include("function.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" />
<script type="text/javascript" src="../js/jquery-1.9.0.min.js"></script>
</head>

<body>


<table cellpadding="0" cellspacing="0" border="0" width="100%">
<tr>
<td width="8%" valign="top">



<?php include("left.php");?>

</td>




<td width="92%" valign="top">

<table cellpadding="0" cellspacing="1" bgcolor="#333333" class="tables" style="width:1050px;">
 
 <!-- <tr>
    <td colspan="12">
	
	<form name="myform" method="post" action="" onSubmit="return Form_Submit()">
	<table cellpadding="0" cellspacing="0" border="0">
	<tr>
	<td>smtp：</td>
	<td><input name="smtp" id="smtp" type="text" style="width:150px;" /> <a href="javascript:;" onclick="qq()">QQ邮箱</a> <a href="javascript:;" onclick="aaa()">163邮箱</a> <a href="javascript:;" onclick="bbb()">126邮箱</a></td>
	</tr>
	<tr>
	<td>端口：</td><td><input name="duankou" id="duankou" type="text" style="width:50px;" value="25" /></td>
	</tr>
	<tr>
	<td>邮箱账号：</td><td><input name="user" id="user" type="text" style="width:150px;" /> 请填写完整，如：abcd@163.com</td>
	</tr>
	<tr>
	<td>邮箱密码：</td><td><input name="pass" id="pass" type="text" style="width:150px;" /></td>
	</tr>
	<tr>
	<td></td><td><input name="submit" type="submit" value="添加" /></td>
	</tr>
	</table>
</form>


	</td>

  </tr> -->
 
 
  <tr>
    <td width="31"><b>ID</b></td>
    <td width="97"><b>smtp</b></td>
    <td width="83"><b>端口</b></td>
    <td width="49"><b>邮箱账号</b></td>
    <td width="68"><b>邮箱密码</b></td>
    <td width="106"><b>操作</b></td>
	
  </tr>
  <?Php
//查询信息总的条数
$db_num_sql=mysql_query("select * from email_user $where order by id desc");	
$db_num = mysql_num_rows($db_num_sql);
//每页显示的条数  
  $page_size=15;
//总条目数  
  $nums=$db_num;  
//每次显示的页数  
  $sub_pages=15;  
//得到当前是第几页  
 $pageCurrent=$_GET['pn']; 

if(!$pageCurrent) $pageCurrent=1;  
 
$page_num=$pageCurrent-1;
$page_num=$page_num*$page_size;

  
  
$sql=mysql_query("select * from email_user $where order by id desc limit $page_num,$page_size");
while($row=mysql_fetch_array($sql)){
?>
  <tr>
  <td width="89"><?php echo $row['id'];?></td>
	<td width="89"><?php echo $row['smtp'];?></td>
	<td width="89"><?php echo $row['duankou'];?></td>
	<td width="68"><?php echo $row['user'];?></td>
	<td width="74"><?php echo $row['pass'];?></td>
    <td width="50">
	<a href="?id=<?php echo $row['id'];?>&action=del" onclick="JavaScript:return confirm('确定删除吗？')">删除</a>	</td>
  </tr>
  <?php
}
?>
  <tr>
    <td colspan="12">
	<?php
$subPages=new SubPages($page_size,$nums,$pageCurrent,$sub_pages,"?pn=",2); 

?>
	</td>

  </tr>


</table></td>
</tr>
</table>


<?php
if($_GET['action']=='del'){

mysql_query("delete from email_user where id='".$_GET['id']."'");
echo '<script language="javascript">
alert("删除成功.");
self.location="email.php";
</script>';


}


if($_POST['submit']){

$smtp = trim($_POST['smtp']);
$duankou = trim($_POST['duankou']);
$user = trim($_POST['user']);
$pass = trim($_POST['pass']);

mysql_query("INSERT INTO `email_user` (`id`, `smtp`, `duankou`, `user`, `pass`) VALUES ('', '".$smtp."', '".$duankou."', '".$user."', '".$pass."')");

echo '<script language="javascript">
alert("添加成功.");
self.location="email.php";
</script>';


}
?>
<script language="javascript">
function qq(){
$('#smtp').val("smtp.qq.com");
}

function aaa(){
$('#smtp').val("smtp.163.com");
}

function bbb(){
$('#smtp').val("smtp.126.com");
}
</script>

 <script type="text/javascript">
function Form_Submit(){

	
	if(document.getElementById("smtp").value==""){
		alert("smtp不能为空.");
		return false;
	}
	
	
	if(document.getElementById("duankou").value==""){
		alert("端口不能为空.");
		return false;
	}
	
	if(document.getElementById("user").value==""){
		alert("邮箱账号不能为空.");
		return false;
	}
	
	if(document.getElementById("pass").value==""){
		alert("邮箱密码不能为空.");
		return false;
	}
	


} 

</script>

</body>
</html>
