﻿<?php
include("pass.php");
//链接mysql
$mysql_server_name=$_SERVER['cfg_db_host']; //数据库服务器名称
$mysql_username=$_SERVER['cfg_db_usr']; // 连接数据库用户名
$mysql_password=$_SERVER['cfg_db_pwd']; // 连接数据库密码
$mysql_database=$_SERVER['cfg_db_table']; // 数据库的名字
$con=@mysql_connect($mysql_server_name,$mysql_username,$mysql_password) or die("连接远程服务器失败！");
mysql_select_db($mysql_database,$con);
mysql_query("SET NAMES 'utf8'");
mysql_query("set sql_mode=''");
date_default_timezone_set ("Asia/Chongqing"); 

//////////////////计算时间差

function timediff($begin_time,$end_time) 
{ 
      if($begin_time < $end_time){ 
         $starttime = $begin_time; 
         $endtime = $end_time; 
      } 
      else{ 
         $starttime = $end_time; 
         $endtime = $begin_time; 
      } 
      $timediff = $endtime-$starttime; 
      $days = intval($timediff/86400); 
      $remain = $timediff%86400; 
      $hours = intval($remain/3600); 
      $remain = $remain%3600; 
      $mins = intval($remain/60); 
      $secs = $remain%60; 
      $res = array("day" => $days,"hour" => $hours,"min" => $mins,"sec" => $secs); 
      return $res; 
}


?>