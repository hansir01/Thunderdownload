<table width="112" cellpadding="0" cellspacing="1" bgcolor="#333333" class="tables" style="width:80px;">
<tr>
<td width="108"><a href="main.php">用户管理</a></td>
</tr>
<!-- <tr>
<td width="108"><a href="daili.php">代理管理</a></td>
</tr> -->
<tr>
<td width="108"><a href="domain.php">域名管理</a></td>
</tr>
<tr>
<td width="108"><a href="logs.php">记录管理</a></td>
</tr>
<tr>
<td width="108"><a href="email.php">smtp设置</a></td>
</tr>

<tr>
<td width="108"><a href="admin.php">后台密码</a></td>
</tr>

</table>