﻿<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" />

</head>

<body>
<?php
include("../config.php");
include("function.php");
if($_POST['submit']){

$c_user=trim($_POST['user']);
$c_pass=trim($_POST['pass']);

if($c_user==$user && $c_pass==$pass){
$_SESSION['c_user'] = $user;
echo '<script language="javascript">
top.location="main.php";
</script>';
exit();
}else{

echo '<script language="javascript">
alert("管理面账号or密码错误.");
top.location="login.php";
</script>';
exit();


}




}


?>
<form name="myform" action="" method="post">
<table cellpadding="0" cellspacing="1" bgcolor="#333333" class="tables" style="width:310px; margin:0px auto;margin-top:200px;">
<tr>
<td width="95">管理员账号</td>
<td width="200">
<input name="user" type="text" style="width:182px;" />
</td>
</tr>
<tr>
<td>管理员密码</td>
<td><input name="pass" type="password" style="width:182px;" /></td>
</tr>
<tr>
<td></td>
<td><input name="submit" type="submit" value="开始登录"  /></td>
</tr>

</table>

</form>


</body>
</html>
