﻿<?php
include("_C.php");
include("../config.php");
include("../function/page.php");
include("function.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" />
</head>

<body>


<table cellpadding="0" cellspacing="0" border="0" width="100%">
<tr>
<td width="8%" valign="top">



<?php include("left.php");?>

</td>




<td width="92%" valign="top">
<table cellpadding="0" cellspacing="1" bgcolor="#333333" class="tables" style="width:900px;">

  <tr>
    <td colspan="9">
	<form name="chaxun" method="get" action="">
	用户名：<input name="chaxun_user" type="text" style="width:100px;" />
	<input name="chaxun_submit" type="submit" value="检索" />
	</form>
	</td>

  </tr>


  <tr>
    <td width="34"><b>ID</b></td>
    <td width="70"><b>所属用户</b></td>
	<td width="104"><b>所属域名</b></td>
    <td width="99"><b>QQ号码</b></td>
    <td width="185"><b>IP</b></td>
    <td width="179"><b>来访时间</b></td>
    <td width="62"><b>操作</b></td>
  </tr>
  <?Php
  
    if($_GET['chaxun_submit']){

if($_GET['chaxun_user']!=''){

$chaxun_sql=mysql_query("select * from users where username='".$_GET['chaxun_user']."'");
$chaxun_row = mysql_fetch_array($chaxun_sql);

$where= "where uid='".$chaxun_row['id']."'";

}


}

if($_GET['domain']!=''){
$where= "where yid='".$_GET['domain']."'";

} 




//查询信息总的条数
$db_num_sql=mysql_query('SELECT * FROM (SELECT * FROM `logs` '.$where.' ORDER BY `id` DESC ) t GROUP BY `qq` ORDER BY `id` DESC');	
$db_num = mysql_num_rows($db_num_sql);
//每页显示的条数  
  $page_size=15;  
//总条目数  
  $nums=$db_num;  
//每次显示的页数  
  $sub_pages=10;  
//得到当前是第几页  
 $pageCurrent=$_GET['pn']; 

if(!$pageCurrent) $pageCurrent=1;  
 
$page_num=$pageCurrent-1;
$page_num=$page_num*$page_size;  




  
  
  
  
$sql=mysql_query('SELECT * FROM (SELECT * FROM `logs` '.$where.' ORDER BY `id` DESC ) t GROUP BY `qq` ORDER BY `id` DESC LIMIT ' .$page_num.',' . $page_size);
while($row=mysql_fetch_array($sql)){
$data = unserialize($row['data']);
?>
  <tr>
    <td width="34"><?php echo $row['id'];?></td>
	<td width="70">
	<?php
	$a_sql=mysql_query("select * from users where id='".$row['uid']."'");
	$a_row=mysql_fetch_array($a_sql);
	echo $a_row['username'];
	?>	</td>
    <td width="104"><?php
	$b_sql=mysql_query("select * from domain where id='".$row['yid']."'");
	$b_row=mysql_fetch_array($b_sql);
	echo $b_row['url'];
	?>    </td>
    <td width="99"><?php echo $row['qq'];?> </td>
    <td width="97">
	<?php 
		echo $data['ip'].$data['ip_city'];
		?>	 </td>
	
    <td width="179">
	<?php 
		echo date("Y-m-d H:i:s",$data['time']);
		?>	</td>
    <td width="62"><a href="?id=<?php echo $row['id'];?>" onclick="JavaScript:return confirm('确定删除吗？')">删除</a> </td>
  </tr>
  <?php
}
?>

<tr>
    <td colspan="9">
	<?php
$subPages=new SubPages($page_size,$nums,$pageCurrent,$sub_pages,"?chaxun_user=$_GET[chaxun_user]&chaxun_submit=检索&domain=$_GET[domain]&pn=",2); 

?>
	</td>

  </tr>

</table></td>
</tr>
</table>
<?php

//删除记录
if($_GET['id']!=''){
$sql = "delete from `logs` where `id` ='".$_GET['id']."' ";

mysql_query($sql);
echo '<script language="javascript">
alert("删除成功.");
window.history.back(-1);
</script>';
}


?>


</body>
</html>
