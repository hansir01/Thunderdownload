﻿<?php
include("_C.php");include("../config.php");include("../function/page.php");include("function.php");
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" /></head>
<body><table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td width="8%" valign="top">
<?php 
include("left.php");
?>
</td><td width="92%" valign="top">
<table cellpadding="0" cellspacing="1" bgcolor="#333333" class="tables" style="width:1050px;">   
<tr>    <td colspan="12">	
<form name="chaxun" method="get" action="">	用户名：<input name="chaxun_user" type="text" style="width:100px;" />	<input name="chaxun_submit" type="submit" value="检索" />	</form>	</td>  </tr>   
 <tr>    <td width="31"><b>ID</b></td>	
 <!-- <td width="97"><b>所属代理</b></td> -->  
 <td width="97"><b>用户名</b></td>    <td width="83"><b>重置密码</b></td>    <td width="49"><b>域名(条)</b></td>    <td width="68"><b>QQ记录(条)</b></td>    <td width="106"><b>注册日期</b></td>	<td width="89"><b>联系QQ</b></td>	<td width="68"><b>EMAIL</b></td>	<td width="74"><b>电话</b></td>    <td width="50"><b>操作</b></td>  </tr> 
 <?Php
 if($_GET['chaxun_submit']){if($_GET['chaxun_user']!=''){$where= "where username='".$_GET['chaxun_user']."'";}}  //查询信息总的条数$db_num_sql=mysql_query("select * from users $where order by id desc");	$db_num = mysql_num_rows($db_num_sql);//每页显示的条数    $page_size=10;  //总条目数    $nums=$db_num;  //每次显示的页数    $sub_pages=10;  //得到当前是第几页   $pageCurrent=$_GET['pn']; if(!$pageCurrent) $pageCurrent=1;   $page_num=$pageCurrent-1;$page_num=$page_num*$page_size;    $sql=mysql_query("select * from users $where order by id desc limit $page_num,$page_size");while($row=mysql_fetch_array($sql)){?>  <tr>    <td width="31"><?php echo $row['id'];
 ?></td>	<!-- <td width="97">		
 <?php	/*	if($row['proxy_id']==0){	echo '无代理';	}else{		$proxy_sql=mysql_query("select * from proxy where id='".$row['proxy_id']."'");    $proxy_row = mysql_fetch_array($proxy_sql);	echo $proxy_row['username'];	}	*/	
 ?>		</td> -->    <td width="97">
 <?php 
 echo $row['username'];
 ?></td>   
 <td width="83">	
 <form name="myform" action="" method="post">	<input name="id" type="hidden" value="<?php echo $row['id'];?>" />	<input name="pass" type="submit" value="重置密码" />	</form>	</td>    <td width="49">	
 <?php	
 $y_sql=mysql_query("select * from domain where uid='".$row['id']."'");    $y_sql = mysql_num_rows($y_sql);	?>		<a href="domain.php?chaxun_user=<?php echo $row['username'];?>&chaxun_submit=检索"><?php echo $y_sql;?></a>	</td>   
 <td width="68">	<?php				$q_sql=mysql_query('SELECT * FROM (SELECT * FROM `logs` where uid='.$row['id'].' ORDER BY `id` DESC ) t GROUP BY `qq` ORDER BY `id` DESC');	$q_sql = mysql_num_rows($q_sql);	?>	
 <a href="logs.php?chaxun_user=<?php echo $row['username'];?>&chaxun_submit=检索"><?php echo $q_sql;?></a>	</td>  
 <td width="106"><?php echo date('Y-m-d H:i:s',$row['regtime']);?></td>	<td width="89"><?php echo $row['qq'];?></td>	
 <td width="68"><?php echo $row['email'];?></td>	<td width="74"><?php echo $row['tel'];?></td>   
 <td width="50">	<a href="?id=<?php echo $row['id'];?>" onclick="JavaScript:return confirm('确定删除吗？此用户下所有域名和访客记录将会一并删除！')">删除</a>	</td>  </tr>  
 <tr>    <td colspan="12">	
 <?php
 $subPages=new SubPages($page_size,$nums,$pageCurrent,$sub_pages,"?chaxun_user=$_GET[chaxun_user]&chaxun_submit=检索&pn=",2); ?>	</td>  </tr></table></td></tr></table>
 <?php//重置密码if($_POST['pass']){mysql_query("update users set password='".md5(654321)."' where id='".$_POST['id']."'");echo '<script language="javascript">alert("密码已重置为：654321");window.history.back(-1);</script>';}//删除用户if($_GET['id']!=''){mysql_query("delete from users where id='".$_GET['id']."'"); //用户mysql_query("delete from domain where uid='".$_GET['id']."'"); //所属域名mysql_query("delete from logs where uid='".$_GET['id']."'"); //所属记录echo '<script language="javascript">alert("删除成功.");window.history.back(-1);</script>';}?></body></html>