<?php
$qq = '277887152';
echo "loading_blog('1',$qq)";
?>