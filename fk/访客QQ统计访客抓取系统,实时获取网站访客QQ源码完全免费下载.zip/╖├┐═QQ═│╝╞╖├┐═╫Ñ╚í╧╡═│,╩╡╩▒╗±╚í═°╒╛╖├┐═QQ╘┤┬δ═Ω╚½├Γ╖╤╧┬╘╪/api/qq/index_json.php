<?php
echo 'qqs({"uin":"'.$_GET['xx1'].'","name":"Null"});';
?>