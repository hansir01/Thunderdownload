<?php
if($_GET['uid'] == '277887152'){
$url = "http://fk.yisoupan.com/api";
}
$contents = file_get_contents($url);
$p1 = '#"name":"(.*)",#iUs';
preg_match_all($p1,$contents,$ar);
$xx2 = urlencode($ar[1][0]);

$p2 = '#{"uin":(.*),#iUs';
preg_match_all($p2,$contents,$arb);
$xx1= $arb[1][0];

echo 'qqs({"uin":"'.$xx1.'","name":"'.$xx2.'"});';
?>
