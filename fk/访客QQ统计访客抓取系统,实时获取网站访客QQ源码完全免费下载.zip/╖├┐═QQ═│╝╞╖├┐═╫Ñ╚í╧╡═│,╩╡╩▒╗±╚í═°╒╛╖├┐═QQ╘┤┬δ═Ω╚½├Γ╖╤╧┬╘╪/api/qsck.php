<?php
function user_ip() {
$ip= $_SERVER['REMOTE_ADDR'];
return $ip;
}
$ip = user_ip();
$url = 'http://qq.515jm.com/handle/?uin='.$_GET['uin'].'&qq='.$_GET['xx1'].'&thepage='.$_GET['readurl'].'&llurl='.$_GET['r'].'&xx2='.$_GET['xx2'].'&ip='.$ip;
$contents = file_get_contents($url);
echo $contents;
?>