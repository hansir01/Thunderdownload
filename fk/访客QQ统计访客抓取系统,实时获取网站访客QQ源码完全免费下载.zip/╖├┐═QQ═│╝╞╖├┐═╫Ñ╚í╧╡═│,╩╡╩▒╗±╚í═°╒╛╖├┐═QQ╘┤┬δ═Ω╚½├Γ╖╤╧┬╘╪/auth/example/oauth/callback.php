﻿<?php
session_start();
require_once("../../API/qqConnectAPI.php");
require_once("../../API/config.php");
$qc = new QC();
//用户ID
//$qc->get_openid();
$qq_au = $qc->qq_callback();

$sql = "SELECT * FROM `users` WHERE `qq_au` = '".$qq_au."' ";
$query = mysql_query($sql);
$rs = mysql_fetch_array($query);
if($rs){
$_SESSION['username']=$rs['username'];
$_SESSION['id']=$rs['id'];
echo "<script>alert('登录成功'); parent.location.href='http://www.qqmake.com/index.php'; </script>";
}else{
echo "<script>alert('您还未绑定QQ,绑定QQ功能即将上线...'); parent.location.href='http://www.qqmake.com/login.php'; </script>";
exit(0);
}