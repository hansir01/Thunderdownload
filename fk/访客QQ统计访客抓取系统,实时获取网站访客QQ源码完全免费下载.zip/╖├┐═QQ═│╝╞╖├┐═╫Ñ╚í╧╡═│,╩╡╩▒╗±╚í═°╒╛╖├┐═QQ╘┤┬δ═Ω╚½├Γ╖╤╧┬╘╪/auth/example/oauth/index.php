<?php

require_once("../../API/qqConnectAPI.php");
$qc = new QC();
$qc->qq_login();
