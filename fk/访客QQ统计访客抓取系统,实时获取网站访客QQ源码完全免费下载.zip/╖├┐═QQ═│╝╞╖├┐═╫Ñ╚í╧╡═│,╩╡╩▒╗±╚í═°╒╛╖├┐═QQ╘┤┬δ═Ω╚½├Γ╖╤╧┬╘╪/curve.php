<?php 
/*
    @ 注意 文件要为utf-8 才能在flash中显示中文
*/
 
include './php-ofc-library/open-flash-chart.php'; 
include("_C.php");

$year = array();
$price = array();
$count = 30;


for($i = 0 ; $i<$count ;$i++){
    //日期
    $j = 29 -$i;
    $year[] = date('m-d',strtotime('-'.$j.' day'));
    $dateTmp = date('Ymd',strtotime('-'.$j.' day'));
    //点 描述
    //$val = rand(2,400);
    $val = query_num("logs","where time='".$dateTmp."' and uid='".$_SESSION['id']."' group  by qq");
	
	
	$d = new solid_dot($val);//实心点
    $d->size(3)->halo_size(1);// 设置点的大小 size 3  表示点的大小   halo_size 1 表示点外边有一个大1的同心圆
    $price[] = $d->colour('#D02020')->tooltip('日期：'.$dateTmp.'<br>QQ数量：'.$val);
    
	}

 
$chart = new open_flash_chart(); 
 
//$title = new title( '线性图 demo' ); //标题内容
//$title->set_style( "{font-size: 20px; color: #A2ACBA; text-align: left;}" ); //标题样式
//$chart->set_title( $title ); 

 //第一条线
$area = new area(); 
$area->set_colour( '#3E94E1' ); //设置线条颜色
$area->set_default_dot_style( new hollow_dot() );//设置点的样式
$area->set_fill_colour( '#D2EBFF' );//区域填充颜色
$area->set_fill_alpha( 0.4 );//设置透明度
$area->set_values( $price ); // 设置显示数据
//$area->set_key( 'price', 12 ); //price为线条意义描述 12表示字体大小 

$chart->add_element( $area ); 

 
$x_labels = new x_axis_labels(); 
$x_labels->set_steps( 2 ); //设置x轴标签数据的间隔
//$x_labels->set_vertical(); //设置x轴标签为垂直    不设置默认为文字水平
$x_labels->set_colour( '#FF0000' ); //x轴 文字描述 颜色
$x_labels->set_size( 13 );  //设置x轴标签字体大小 
$x_labels->set_labels( $year ); 
 
$x = new x_axis(); 
$x->set_colour( '#ff0000' ); //X 轴线颜色
$x->set_grid_colour( '#D7E4A3' ); //  轴线颜色
$x->set_offset( true ); 
$x->set_steps(4); 
// Add the X Axis Labels to the X Axis 
$x->set_labels( $x_labels ); 
 
$chart->set_x_axis( $x ); 
 
// 
// LOOK: 
// 
/*
$x_legend = new x_legend( '1983 to 2008' ); 
$x_legend->set_style( '{font-size: 20px; color: #778877}' ); 
$chart->set_x_legend( $x_legend ); 
*/
// 
// remove this when the Y Axis is smarter 
// 
$y = new y_axis(); 
$y->set_range( 0, 500,50); 
$chart->add_y_axis( $y ); 
 
echo $chart->toPrettyString(); 
?>