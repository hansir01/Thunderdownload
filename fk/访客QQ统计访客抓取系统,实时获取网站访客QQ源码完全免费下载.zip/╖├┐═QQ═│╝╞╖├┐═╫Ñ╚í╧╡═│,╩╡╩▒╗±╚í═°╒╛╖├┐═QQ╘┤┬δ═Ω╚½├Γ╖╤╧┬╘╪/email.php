<?php
include("_C.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>

<link rel="stylesheet" href="css/css.css" media="screen" />
<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
<script type="text/javascript" src="js/jquery.caretInsert.js"></script>
<script type="text/javascript" src="tinymce/tinymce.min.js"></script>
</head>

<body style="background:#FFFFFF;padding-left:15px;padding-right:15px;">
<div class="" >
<?php
$db = query("domain","where id = '".$_GET['id']."' and uid='".$_SESSION['id']."'");
?>
<form name="myform" action="" method="post" onSubmit="return Form_Submit()">
<table cellpadding="0" cellspacing="1" bgcolor="#CCCCCC" width="100%" class="password">

<tr >
<td width="101" class="p_a">所属域名：</td>
<td width="903" class="p_b">
<?php echo $db['url'];?></td>
</tr>

<tr >
<td class="p_a">状态：</td>
<td  class="p_b">
<input type="radio" name="email_state" style="width:30px;" value="1" 
<?php
if($db['email_state'] > '0'){
echo 'checked';
}
?>
/>开启
<input type="radio" name="email_state" style="width:30px;"  value="0"
<?php
if($db['email_state']==''){
echo 'checked';
}
if($db['email_state']=='0'){
echo 'checked';
}
?>
/>关闭
</td>
</tr>


<tr>
<td class="p_a">
发件人：</td>
<td class="p_b">
<input name="email_name"  type="text" style="width:200px;"  value="<?php echo $db['email_name'];?>"/></td>
</tr>

<tr>
<td class="p_a">
邮件标题：</td>
<td class="p_b">
<input name="email_title"  type="text" style="width:500px;"  value="<?php echo $db['email_title'];?>"/>
</td>
</tr>

<tr>
<td class="p_a">
邮件内容：</td>
<td class="p_b" style="padding:5px;">
<div style="line-height:30px;color:#FF0000;">
您可以在<b>标题</b>和<b>内容</b>中插入访客信息变量。<br />如：系统已经获取到您的信息：QQ：[qq] 昵称：[name] 访问网址：[url] 访问时间：[time]
</div>
  <textarea id="editor_id" name="email_content" style="width:390px;height:80px;margin-top:5px;margin-bottom:5px;"><?php

  echo $db['email_content'];
 
  ?></textarea>
 
</td>
</tr>

<tr>
<td>
</td>
<td style="text-align:left;padding-left:10px;">
<input name="submit" type="submit" class="btn" value="提交" style="width:100px;" /></td>
</tr>

<tr>

<td class="p_a" colspan="2" style="text-align:left;padding-left:140px;">
说明：当获取到用户QQ号码后，系统会自动发送您设置的邮件信息给对方。
</td>
</tr>

</table>
</form>
</div>

<?php
if($_POST['submit']){
$email_state = $_POST['email_state'];
$email_name = $_POST['email_name'];
$email_title = $_POST['email_title'];
$email_content = addslashes($_POST['email_content']);


query_update("domain","email_state='".$email_state."',email_name='".$email_name."',email_title='".$email_title."',email_content='".$email_content."' where id='".$db['id']."' and uid='".$_SESSION['id']."'");
skip("邮件推送配置信息已保存.","weblist.php");

}
?>

<script>
tinymce.init({
    selector: "textarea",
    plugins: [
        "advlist autolink lists link image charmap print preview anchor",
        "searchreplace visualblocks code fullscreen",
        "insertdatetime media table contextmenu paste"
    ],
    language : "zh_CN",
    toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
});
</script>
</body>
</html>
