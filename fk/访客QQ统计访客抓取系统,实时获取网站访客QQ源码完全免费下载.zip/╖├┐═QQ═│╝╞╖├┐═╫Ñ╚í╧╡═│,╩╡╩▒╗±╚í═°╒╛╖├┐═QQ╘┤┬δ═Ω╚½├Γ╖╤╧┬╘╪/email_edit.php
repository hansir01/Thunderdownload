<?php
include("_C.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/email_css.css" media="screen" />
<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
<script type="text/javascript" src="img/js.js"></script>

</head>
<body>
<?php
$e = query("email_user","where id='".$_GET['id']."' and uid='".$_SESSION['id']."'");
?>

<div class="tgy-main tgy-main_a">

<style>
.p_b input{width:200px;}
.sm {
color:#999999;
}
</style>
<form name="myform" action="" method="post" onSubmit="return Form_Submit()">
<table cellpadding="0" cellspacing="0" border="0" width="100%" class="password">
<tr>
<td width="55" class="p_a">Smtp</td>
<td width="932" class="p_b"><input  name="smtp" id="smtp" type="text"  value="<?php echo $e['smtp'];?>"/> <font class="sm">Smtp服务器地址</font></td>
</tr>
<tr>
<td class="p_a">端口</td>
<td class="p_b"><input name="duankou" id="duankou" value="<?php echo $e['duankou'];?>" type="text" /> <font class="sm">默认端口25</font></td>
</tr>
<tr>
<td class="p_a">邮箱账号</td>
<td class="p_b"><input name="user" id="user" type="text" value="<?php echo $e['user'];?>"/> <font class="sm">如：baidu@163.com</font></td>
</tr>
<tr>
<td class="p_a">邮箱密码</td>
<td class="p_b"><input name="pass" id="pass" type="password" value="<?php echo $e['pass'];?>"/></td>
</tr>
<tr>
<td class="p_a"></td>
<td class="p_b">
<input name="submit" class="btn" type="submit" value="确定修改" style="width:110px;" />
</td>
</tr>
</table>
</form>

<?php

if($_POST['submit']){

query_update("email_user","smtp='".$_POST['smtp']."',duankou='".$_POST['duankou']."',user='".$_POST['user']."',pass='".$_POST['pass']."' where id='".$_GET['id']."' and uid='".$_SESSION['id']."'");

skip("发件箱修改成功.","email_list.php","parent");

exit();
}


?>

       <script type="text/javascript">
function Form_Submit(){

	
	if(document.getElementById("smtp").value==""){
		alert("请填写Smtp");
		return false;
	}
	
	if(document.getElementById("duankou").value==""){
		alert("请填写端口");
		return false;
	}
	
	if(document.getElementById("user").value==""){
		alert("请填写邮箱账号");
		return false;
	}
	
	
		if(document.getElementById("pass").value==""){
		alert("请填写邮箱密码");
		return false;
	}
	





} 

</script>

</div>

</body>
</html>
