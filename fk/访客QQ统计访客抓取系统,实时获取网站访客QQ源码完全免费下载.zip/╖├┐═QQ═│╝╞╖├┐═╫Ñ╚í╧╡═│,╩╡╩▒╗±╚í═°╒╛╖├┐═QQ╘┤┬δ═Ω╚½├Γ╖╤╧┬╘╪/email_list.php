<?php
include("_C.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" />
<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
<script language="javascript" src="lhgdialog/lhgdialog.min.js?self=true&skin=discuz"></script>
<script language="javascript">
(function(config){
    
    config['fixed'] = true;
	 config['extendDrag'] = true; 
    config['max'] = false;
    config['min'] = false;
   
    config['cancelVal'] = 'Cancel';
    // [more..]
})($.dialog.setting);
</script>

</head>

<body>




<div class="right" >

<div style="width:100%;margin:0px auto;margin-bottom:15px;">
<a class="btn" href="javascript:;" onclick="email()"><font>添加发件箱</font></a>
</div>


<table cellpadding="0" cellspacing="1" border="0" bgcolor="#D6E6F1" width="100%" style="margin:0px auto;" >
<tr class="qqlist">

<td >Smtp</td>

<td >端口</td>
<td >邮箱账号</td>
<td>邮箱密码</td>
<td>操作</td>

</tr>



<?php



//查询信息总的条数

$db_num = query_num("email_user","where uid='".$_SESSION['id']."'");
//每页显示的条数  
  $page_size=100;  
//总条目数  
  $nums=$db_num;  
//每次显示的页数  
  $sub_pages=5;  
//得到当前是第几页  
 $pageCurrent=$_GET['pn']; 

if(!$pageCurrent) $pageCurrent=1;  
 
$page_num=$pageCurrent-1;
$page_num=$page_num*$page_size;



$list_sql = mysql_query('SELECT * FROM email_user where uid='.$_SESSION['id'].'  ORDER BY `id` DESC LIMIT ' .$page_num.',' . $page_size);


while($value=mysql_fetch_array($list_sql)){


?>

<tr class="qqlist_a">

<td ><?php echo $value['smtp'];?></td>
<td ><?php echo $value['duankou'];?></td>
<td><?php echo $value['user'];?></td>
<td>*********</td>
				
	<td width="230"><a href="javascript:;"  onclick="email_edit('<?php echo $value['id'];?>')">修改邮箱</a><a style="margin-left:10px;" href="?id=<?php echo $value['id'];?>&action=del"  onclick="JavaScript:return confirm('确认删除邮箱吗？')">删除邮箱</a></td>
</tr>

<?php

}


?>




</table>

</div>
<?php
if($_GET['action']=='del'){

del("email_user","where id='".$_GET['id']."' and uid='".$_SESSION['id']."'");
skip("邮箱已删除.","email_list.php");

}
?>
<script language="javascript">



function email(){

$.dialog({
id: '1',
title:'添加发件箱',
width:630,
height:350,
content: 'url:email_insert.php'
});

}


function email_edit(id){

$.dialog({
id: '2',
title:'修改发件箱',
width:630,
height:350,
content: 'url:email_edit.php?id='+id
});

}

</script>



</body>
</html>
