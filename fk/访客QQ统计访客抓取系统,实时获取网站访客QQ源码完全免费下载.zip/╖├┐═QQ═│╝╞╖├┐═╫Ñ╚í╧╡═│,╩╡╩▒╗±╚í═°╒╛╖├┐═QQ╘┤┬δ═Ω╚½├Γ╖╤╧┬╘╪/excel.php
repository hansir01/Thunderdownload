<?php
require_once 'phpExcel/PHPExcel.php';
require_once 'phpExcel/PHPExcel/IOFactory.php';
$objPHPExcel = new PHPExcel();
$objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
							 ->setLastModifiedBy("Maarten Balliauw")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");
							 
$objPHPExcel->setActiveSheetIndex(0);

/*
$objRichText = new PHPExcel_RichText();
$objRichText->createText('');
$objPayable = $objRichText->createTextRun('PHP导出的Excel');
$objPayable->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_RED ));
$objPayable->getFont()->setBold(true);
$objPayable->getFont()->setSize(24);


$objPHPExcel->getActiveSheet()->getCell('B1')->setValue($objRichText);
$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);		// 加粗
$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setSize(24);			// 字体大小
$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_RED);	// 文本颜色
$objPHPExcel->getActiveSheet()->getStyle('A1:J1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A1:J1')->getFill()->getStartColor()->setARGB('00FFFFE3');			// 底纹
*/

$objPHPExcel->getActiveSheet()->getStyle('A1:J1')->getFont()->setBold(true); //加粗
$objPHPExcel->getActiveSheet()->getStyle('A1:J1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A1:J1')->getFill()->getStartColor()->setARGB('CCCCCC');			// 底纹
// 列宽
//$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(18);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(18);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(18);
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(20);
$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(20);
$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(20);
// 行高
for($i = 2; $i <= 17; $i++)
{
	$objPHPExcel->getActiveSheet()->getRowDimension($i)->setRowHeight(22);
}

$objPHPExcel->getActiveSheet()->setCellValue('A1', '访问时间');
$objPHPExcel->getActiveSheet()->setCellValue('B1', '首访时间');
$objPHPExcel->getActiveSheet()->setCellValue('C1', '昵称');
$objPHPExcel->getActiveSheet()->setCellValue('D1', 'QQ号码');
$objPHPExcel->getActiveSheet()->setCellValue('E1', '来路关键词');
$objPHPExcel->getActiveSheet()->setCellValue('F1', '入口页');
$objPHPExcel->getActiveSheet()->setCellValue('G1', '最后停留页');
$objPHPExcel->getActiveSheet()->setCellValue('H1', 'IP');
$objPHPExcel->getActiveSheet()->setCellValue('I1', '来源地区');
$objPHPExcel->getActiveSheet()->setCellValue('J1', '访问页数');

/*
for($i = 2; $i <= 16; $i++)
{
	$objPHPExcel->getActiveSheet()->getStyle('A' . $i)->getFont()->setBold(true);		// 加粗
}
*/



//=================================================== SQL =================

include("function/session.php");
include("config.php");
include("function/function.php");

$week = date('Ymd',(time()-((date('w')==0?7:date('w'))-1)*86400)); //本周一
$week_a = date('Ymd',(time()+(7-(date('w')==0?7:date('w')))*86400)); //本周日
$yue = date('Ymd',strtotime(date('Y-m', time()).'-01 00:00:00')); //本月第一天
$yue_a = date('Ymd',strtotime(date('Y-m', time()).'-'.date('t', time()).' 00:00:00')); //本月最后一天
//查询条件

if(is_numeric($_GET['domain'])){ //域名ID
$where = " and yid='".$_GET['domain']."'";
}

if($_GET['time']=='j'){  //今天
$where.= " and time='".date("Ymd")."'";
}

if($_GET['time']=='z'){  //昨天
$where.= " and time='".date("Ymd",strtotime('-1 day'))."'";
}

if($_GET['time']=='week'){  //本周
$where.= " and time >='".$week."' and time <= '".$week_a."'";
}

if($_GET['time']=='yue'){  //本月
$where.= " and time >='".$yue."' and time <= '".$yue_a."'";
}

if($_GET['time']=='nian'){  //本年
$nian = date("Y");
$where.= " and time like  '$nian%'";
}


###分类

if($_GET['fenlei']!=''){  
$where.= " and state ='".$_GET['fenlei']."'";
}



//查询信息总的条数
$db_num_sql=mysql_query("select *, qq from logs where uid='".$_SESSION['id']."' $where group by qq order by id desc");	
$db_num = mysql_num_rows($db_num_sql);

if($db_num < '1'){
skip("没有记录可供导出.","right.php?time=".$_GET['time']."&domain=".$_GET['domain']."&fenlei=".$_GET['fenlei']."");
exit();
}




$list_sql = mysql_query('SELECT * FROM (SELECT * FROM `logs` where uid='.$_SESSION['id'].$where.' ORDER BY `id` DESC ) t GROUP BY `qq` ORDER BY `id` DESC');

$ina=2;

while($value=mysql_fetch_array($list_sql)){
$value_data = unserialize($value['data']);
//访问时间
if(date("Y-m-d",$value_data['time']) == date("Y-m-d") ){
$fangwen_time = date("H:i:s",$value_data['time']);
}else{
$fangwen_time = date("m-d H:i:s",$value_data['time']);
}
//首访时间
$s_date = query("logs","where qq='".$value['qq']."' order by id asc",1);
$s_date = unserialize($s_date['data']);

if(date("Y-m-d",$s_date['time']) == date("Y-m-d") ){
$shoufang_time = date("H:i:s",$s_date['time']);
}else{
$shoufang_time = date("m-d H:i:s",$s_date['time']);
}
//入口页
 $cpage_date = query("logs","where qq='".$value['qq']."' order by id asc",1);
 $cpage_date = unserialize($cpage_date['data']);

$i = $ina++;
ob_clean();//清理excel内容之间的缓冲区，否则导出内容乱码

$objPHPExcel->getActiveSheet()->setCellValue('A'.$i, $fangwen_time);
$objPHPExcel->getActiveSheet()->setCellValue('B'.$i, $shoufang_time);
$objPHPExcel->getActiveSheet()->setCellValue('C'.$i, $value_data['name']);
$objPHPExcel->getActiveSheet()->setCellValue('D'.$i, $value['qq']);
$objPHPExcel->getActiveSheet()->setCellValue('E'.$i, $value_data['llurl']."-".$value_data['word']);
$objPHPExcel->getActiveSheet()->setCellValue('F'.$i, $cpage_date['rpage']);
$objPHPExcel->getActiveSheet()->setCellValue('G'.$i, $value_data['rpage']);
$objPHPExcel->getActiveSheet()->setCellValue('H'.$i, $value_data['ip']);
$objPHPExcel->getActiveSheet()->setCellValue('I'.$i, $value_data['ip_city']);
$objPHPExcel->getActiveSheet()->setCellValue('J'.$i, query_num("logs","where qq='".$value['qq']."'"));



}

//============================================= SQL END ============================




// 为excel加图片
/*$objDrawing = new PHPExcel_Worksheet_Drawing();
$objDrawing->setName('Photo');
$objDrawing->setDescription('Photo');
$objDrawing->setPath('http://www.sj586.com/images/logo.jpg');
$objDrawing->setHeight(170);
$objDrawing->setWidth(120);
$objDrawing->setCoordinates('G2');
$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
*/



//$objPHPExcel->getActiveSheet()->getStyle('A17')->getFont()->setBold(true);		// 加粗

$objPHPExcel->setActiveSheetIndex(0);

//直接生成到服务器
/*
$objPHPExcel->getActiveSheet()->setTitle('QQ访客列表');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('PHPExcel.xls');
*/

// 弹出下载  
$objPHPExcel->getActiveSheet()->setTitle('QQ访客统计报表');  
// Set active sheet index to the first sheet, so Excel opens this as the first sheet  
$objPHPExcel->setActiveSheetIndex(0);  
// Redirect output to a clients web browser (Excel5)通知下载  
$fn=date("Y-m-d H:i:s").".xls";
header('Content-Type: application/vnd.ms-excel; charset=utf-8');  
header("Content-Disposition: attachment;filename=$fn");  
header('Cache-Control: max-age=0');  
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');  
$objWriter->save('php://output');  
exit;  

