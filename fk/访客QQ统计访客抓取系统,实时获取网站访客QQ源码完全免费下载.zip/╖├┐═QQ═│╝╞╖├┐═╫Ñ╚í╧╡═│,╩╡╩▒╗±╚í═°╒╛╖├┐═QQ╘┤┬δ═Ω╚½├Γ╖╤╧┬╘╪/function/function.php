<?php
//error_reporting(0);
date_default_timezone_set('PRC');
//过滤POST GET


//链接mysql
$mysql_server_name=$_SERVER['cfg_db_host']; //数据库服务器名称
$mysql_username=$_SERVER['cfg_db_usr']; // 连接数据库用户名
$mysql_password=$_SERVER['cfg_db_pwd']; // 连接数据库密码
$mysql_database=$_SERVER['cfg_db_table']; // 数据库的名字
$con=@mysql_connect($mysql_server_name,$mysql_username,$mysql_password) or die("链接数据库失败！");
mysql_select_db($mysql_database,$con);
mysql_query("SET NAMES 'utf8'");
mysql_query("set sql_mode=''");

//:::::::::::::::::::::::::::::::添加信息::::::::::::::::::::::
function insert($biao,$value){
//查询本表里面的所有字段
$ziduan_sql="select * from $biao";
$ziduan_query=mysql_query($ziduan_sql);
while($field=mysql_fetch_field($ziduan_query)){
$ziduan[]=$field->name.",";
}
$ziduan=implode("",$ziduan);
$len_ziduan=strlen($ziduan);
$ziduan=substr($ziduan,0,$len_ziduan-1);

//把表单提交的内容进行整合
foreach ($value as $v){
$arr[]="'".$v."',";
}
$arr=implode("",$arr);
$len=strlen($arr);
$arr=substr($arr,0,$len-1);
//SQL语句
$sql="INSERT INTO $biao ($ziduan) values ($arr)";
$query=mysql_query($sql);
//echo mysql_error();
}



//:::::::::::::::::::::::查询信息::::::::::::::::::::::

function query($biao,$where,$more=1){

$sql="select * from $biao $where";
$query=mysql_query($sql);
//echo mysql_error();
//查询单条数据
if($more==1){
$db=mysql_fetch_array($query);
return $db;
}
//查询多条数据
if($more==0){
return $query;
}


}


//::::::::::::::::::::::::::::::::查询信息条数::::::::::::::::::::::::::
function query_num($biao,$where){

$sql="select * from $biao $where";
$query=mysql_query($sql);
$db=mysql_num_rows($query);
return $db;
}

//::::::::::::::::::::::::::::::::修改信息::::::::::::::::::::::::::
function query_update($biao,$where){

$sql="update $biao set $where";
$query=mysql_query($sql);
return $query;

}

//::::::::::::::::::::::::::::::::删除信息::::::::::::::::::::::::::

function del($biao,$where){
$query = mysql_query("delete from $biao $where");
return $query;
}



//===============================================================================
//===============================================================================


//;::::::::::::::::::::::::::::::JS跳转：：：：：：：：：：：：：：：：
function skip($name,$url,$leixing='self'){

if($name!=''){

$query = '<script language="javascript">
alert("'.$name.'");
'.$leixing.'.location="'.$url.'";
</script>';

}else{

$query = '<script language="javascript">
'.$leixing.'.location="'.$url.'";
</script>';

}

echo  $query;

}


//::::::::::::::::::::::::::::::::::::;加密

class base64
{
    /**
     * 密钥
     * @param string $string 字符串
     * @param string $encrypt_key 加密/解密字符
     * @return string
     */
    static function keyED($string,$encrypt_key)
    {
        $encrypt_key = md5($encrypt_key);
        $ctr = 0;
        $tmp = '';
        for($i = 0; $i < strlen($string); $i++)
        {
           $ctr = $ctr == strlen($encrypt_key) ? 0 : $ctr;
           $tmp .= $string[$i] ^ $encrypt_key[$ctr++];
        }
        return $tmp;
    }
    
    /**
     * 加密函数
     * @param string $string 字符串
     * @param boolean $rand 是否随机
     * @param string $key 干扰字符
     * @return string 
     */
    static function encrypt($string,$rand=FALSE,$key='VISCMS')
    {
        $encrypt_key = md5(rand(0, 32000));
        $ctr = 0;
        $tmp = '';
        for($i = 0;$i < strlen($string); $i++) 
        {
           $ctr = $ctr == strlen($encrypt_key) ? 0 : $ctr;
            $tmp .= $rand ? $encrypt_key[$ctr].($string[$i] ^ $encrypt_key[$ctr++]) : $string[$i];
        }
        //采用base64_encode加密再将字符串放入函数中再次进行处理
        return base64_encode(base64::keyED($tmp,$key));
        //直接将字符串进行加密处理
        //return $this->keyED($tmp,$key);
    }
    
    /**
     * 解密函数
     * @param string $string 字符串
     * @param boolean $rand 是否随机
     * @param string $key 干扰字符
     */
    static function decrypt($string,$rand=FALSE,$key='VISCMS')
    {
        //使用base64_encode解密再将字符串进行处理
        $string = base64::keyED(base64_decode($string),$key);
        //直接将字符串进行处理
        //$string = $this->keyED($string,$key);
        for($i = 0;$i < strlen($string); $i++)
        {
           $md5 = $string[$i];
           $tmp .= $rand ? $string[++$i] ^ $md5 : $md5;
        }
        return $tmp;
    }
}
$base64 = new base64();

//$encode = $base64->encrypt('鱼爱雪儿');
//$decode = $base64->decrypt($encode);









 /********************************** 
  * 截取字符串(UTF-8)
  *
  * @param string $str 原始字符串
  * @param $position 开始截取位置
  * @param $length 需要截取的偏移量
  * @return string 截取的字符串
  * $type=1 等于1时末尾加'...'不然不加
 *********************************/ 
 function mysubstr($str, $position, $length,$type=1){
  $startPos = strlen($str);
  $startByte = 0;
  $endPos = strlen($str);
  $count = 0;
  for($i=0; $i<strlen($str); $i++){
   if($count>=$position && $startPos>$i){
    $startPos = $i;
    $startByte = $count;
   }
   if(($count-$startByte) >= $length) {
    $endPos = $i;
    break;
   }    
   $value = ord($str[$i]);
   if($value > 127){
    $count++;
    if($value>=192 && $value<=223) $i++;
    elseif($value>=224 && $value<=239) $i = $i + 2;
    elseif($value>=240 && $value<=247) $i = $i + 3;
    else return self::raiseError("\"$str\" Not a UTF-8 compatible string", 0, __CLASS__, __METHOD__, __FILE__, __LINE__);
   }
   $count++;

  }
  if($type==1 && ($endPos-6)>$length){
   return substr($str, $startPos, $endPos-$startPos)."..."; 
       }else{
   return substr($str, $startPos, $endPos-$startPos);     
    }
  
 }
 
 
 
 

//截取字符串，gb2312  utf-8 都支持的。
function cut_str($string, $sublen, $start = 0, $code = 'UTF-8')   
{   
if($code == 'UTF-8')   
{   
$pa = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/";   
preg_match_all($pa, $string, $t_string);   
  
if(count($t_string[0]) - $start > $sublen) return join('', array_slice($t_string[0], $start, $sublen));   
return join('', array_slice($t_string[0], $start, $sublen));   
}   
else  
{   
$start = $start*2;   
$sublen = $sublen*2;   
$strlen = strlen($string);   
$tmpstr = '';   
  
for($i=0; $i<$strlen; $i++)   
{   
if($i>=$start && $i<($start+$sublen))   
{   
if(ord(substr($string, $i, 1))>129)   
{   
$tmpstr.= substr($string, $i, 2);   
}   
else  
{   
$tmpstr.= substr($string, $i, 1);   
}   
}   
if(ord(substr($string, $i, 1))>129) $i++;   
}   
if(strlen($tmpstr)<$strlen ) $tmpstr.="";   
return $tmpstr;   
}   
} 














//////////////////计算时间差

function timediff($begin_time,$end_time) 
{ 
      if($begin_time < $end_time){ 
         $starttime = $begin_time; 
         $endtime = $end_time; 
      } 
      else{ 
         $starttime = $end_time; 
         $endtime = $begin_time; 
      } 
      $timediff = $endtime-$starttime; 
      $days = intval($timediff/86400); 
      $remain = $timediff%86400; 
      $hours = intval($remain/3600); 
      $remain = $remain%3600; 
      $mins = intval($remain/60); 
      $secs = $remain%60; 
      $res = array("day" => $days,"hour" => $hours,"min" => $mins,"sec" => $secs); 
      return $res; 
}
?>