<?php
session_start();
if($_SESSION['username']=='' || $_SESSION['id']==''){
echo '<script language="javascript">
top.location="login.php";
</script>';
exit();
}
?>