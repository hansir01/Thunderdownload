<html>
<head>
<script type="text/javascript">
xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
xmlDoc.async="false";
xmlDoc.load("http://kf.qq.com/cgi-bin/loginTitle");
txt=xmlDoc.getElementsByTagName("root")[0].text;
alert(txt);
</script>
</head>
<body>
<iframe src="http://kf.qq.com/cgi-bin/loginTitle" id="aaa" name="aaa"></iframe>
</body>
</html>
