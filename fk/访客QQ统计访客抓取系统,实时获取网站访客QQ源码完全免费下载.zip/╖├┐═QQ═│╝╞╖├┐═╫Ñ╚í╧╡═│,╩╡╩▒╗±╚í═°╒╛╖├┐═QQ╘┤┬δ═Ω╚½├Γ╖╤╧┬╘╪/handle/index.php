﻿<?php
header("Content-Type: text/html; charset=utf-8");
include("../config.php");
include("../function/function.php");
include_once("../function/word.php");
$db_key = new keyword_h();

//通过请求的域名判断
//if($_SERVER["HTTP_REFERER"] == "")
//{
//echo '邮件发送成功!';exit(0);
//}

$xx1 = $_GET['qq'];



$url1 = "http://r.qzone.qq.com/cgi-bin/user/cgi_personal_card?uin=".$xx1."&fupdate=1&g_tk=2104390454&rd=1405151493";
$contents1 = file_get_contents($url1);
$p1 = '#"nickname":"(.*)",#iUs';

preg_match_all($p1,$contents1,$ar);
$xx2=urldecode($ar[1][0]);


if(!$xx2)
{
echo '未获取昵称';exit(0);
}

//判断权限等:::::::::::::::::::::::::::::::::::
// uin 是域名ID
if(is_numeric($_GET['uin'])){
}else{
exit();
}


$domain = query("domain","where id='".$_GET['uin']."'"); //域名
$user = query("users","where id='".$domain['uid']."'"); //用户

//如果有本域名 并且 也有对应的用户名:::::::::::::::::::::::::::::::::::
if(is_numeric($domain['id']) && is_numeric($user['id']) && $domain['outtime'] > strtotime(date("Y-m-d H:i:s"))){
}else{
exit("url error");
}


//判断域名是否配套::::::::::::::::::::::::::::::::::::::::::::::::::
$domain_url = explode("/",$_GET['thepage']); //原始域名
$domain_url = str_replace("www.","",$domain_url[2]);

$domain_db = query("domain","where id='".$_GET['uin']."' and url like '%".$domain_url."%'");

//if($domain_db['id']==''){
//exit("thepage error");
//}


//////////////////////////////////////////////////第一次访问获取,没有带上获取的QQ
if($_GET['xx3'] < 1){

$qq_hao = $xx1;

//md5判断
//$md5 = md5($qq_hao."rerdei876ra");

//if($md5!=$_GET['md5']){
//echo 'md5错误';
//exit();
//}



//分析来路////////////////////////////
$word = $db_key->getKeyword($_GET['llurl']); 

if(strpos($word,"百度")!==false || strpos($word,"谷歌")!==false || strpos($word,"搜搜")!==false || strpos($word,"搜狗")!==false){
$word = explode("|",$word);
}else{
$_GET['llurl']=='' ? $_GET['llurl']='-' : false;
$word[0] = $_GET['llurl'];
$word[1] = '-';
}

$data['time'] = strtotime(date("Y-m-d H:i:s"));
$data['name'] = $xx2;
$data['llurl'] = $word[0];
$data['word'] = $word[1];

$_GET['thepage']=='' ? $_GET['thepage']='-' : false;
$data['rpage'] = $_GET['thepage'];
$data['cpage'] = '-';
$data['ip'] = $_GET['ip'];

//ip地址 api
$ip = file_get_contents("http://ip.taobao.com/service/getIpInfo.php?ip=".$data['ip']);
$ip = json_decode($ip,true);
$ip = $ip['data']['country'].$ip['data']['region']." ".$ip['data']['city'].$ip['data']['isp'];

$data['ip_city'] = $ip;
$data['miao'] = '5';

$arr=array(
'',
$user['id'],
$domain['id'],
$qq_hao,
serialize($data),
date("Ymd"),
'1'
);
insert("logs",$arr);


//邮件推送
$baseUrl = str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME']));  
$baseUrl = empty($baseUrl) ? '/' : '/'.trim($baseUrl,'/').'/';  
$baseUrl = str_replace("handle/","",$baseUrl);


echo file_get_contents("http://".$_SERVER['SERVER_NAME']."/".$baseUrl."/mail/email.php?id=".$_GET['uin']."&qq=".$qq_hao."&url=".$_GET['thepage']."&name=".$xx2."");



}

//第二次访问带上获取的QQ

if($_GET['xx3'] > '0'){

$db_qq = query("logs","where qq='".$xx1."' order by id desc");

$db_qq_row = unserialize($db_qq['data']);

$data['time'] = $db_qq_row['time'];
$data['name'] = $db_qq_row['name'];
$data['llurl'] = $db_qq_row['llurl'];
$data['word'] = $db_qq_row['word'];
$data['rpage'] = $db_qq_row['rpage'];
$data['cpage'] = $db_qq_row['cpage'];
$data['ip'] = $db_qq_row['ip'];
$data['ip_city'] = $db_qq_row['ip_city'];
$data['miao'] = $db_qq_row['miao']+15;

mysql_query("update logs set data='".serialize($data)."',state='1' where id='".$db_qq['id']."'");



}

?>