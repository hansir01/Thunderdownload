<?php
include("config.php");
include("function/function.php");
if($_GET['blogid'] == 't-35719-1' or $_GET['blogid'] == 't-2078-1' or $_GET['blogid'] == 't-2023-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1955330495&res_mode=0&res_uin=2107288382&offset=0&count=10&page=1&format=json&t=1409042128699&sid=AXpeh3O8a3t9tl45FHQSyDtb";
}elseif($_GET['blogid'] == 't-2119-1' or $_GET['blogid'] == 't-2052-1' or $_GET['blogid'] == 't-2004-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1955330495&res_mode=0&res_uin=3051684056&offset=0&count=10&page=1&format=json&t=1409042128699&sid=AVG88SBQRxP1SlaZsC6CnEm6";
}elseif($_GET['blogid'] == 't-1971-1' or $_GET['blogid'] == 't-2155-1' or $_GET['blogid'] == 't-1915-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1955330495&res_mode=0&res_uin=2244587919&offset=0&count=10&page=1&format=json&t=1409042128699&sid=AdP6yDIt_uZFQ50Vx9NuoJG3";
}elseif($_GET['blogid'] == 't-2043-1' or $_GET['blogid'] == 't-1858-1' or $_GET['blogid'] == 't-2526-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1955330495&res_mode=0&res_uin=1729550164&offset=0&count=10&page=1&format=json&t=1409042128699&sid=AVoAf3jsDyyVHLnRiuPeVa40";
}elseif($_GET['blogid'] == 't-18721-1' or $_GET['blogid'] == 't-19202-1' or $_GET['blogid'] == 't-18843-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1955330495&res_mode=0&res_uin=1485015960&offset=0&count=10&page=1&format=json&t=1409042128699&sid=AZKkD31piq-OXEmk4zIbF4mK";
}elseif($_GET['blogid'] == 't-4185-1' or $_GET['blogid'] == 't-4247-1' or $_GET['blogid'] == 't-4147-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1955330495&res_mode=0&res_uin=3065002168&offset=0&count=10&page=1&format=json&t=1409042128699&sid=AUJi2WCj42mcpAEGuWh70TyM";
}elseif($_GET['blogid'] == 't-4089-1' or $_GET['blogid'] == 't-4242-1' or $_GET['blogid'] == 't-4126-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1955330495&res_mode=0&res_uin=3071634373&offset=0&count=10&page=1&format=json&t=1409042128699&sid=AVLzYNuuvv-6wfLzPKS15l6O";
}elseif($_GET['blogid'] == 't-2146-1' or $_GET['blogid'] == 't-2070-1' or $_GET['blogid'] == 't-36127-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1955330495&res_mode=0&res_uin=2931958118&offset=0&count=10&page=1&format=json&t=1409042128699&sid=AbnSAFe4ZWHYGNuFKgcMcSuh";
}elseif($_GET['blogid'] == 't-36074-1' or $_GET['blogid'] == 't-25330-1' or $_GET['blogid'] == 't-25423-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1955330495&res_mode=0&res_uin=1847424268&offset=0&count=10&page=1&format=json&t=1409042128699&sid=AeaOAcReNNhYn0OSfrU5PrKh";
}elseif($_GET['blogid'] == 't-36098-1' or $_GET['blogid'] == 't-36101-1' or $_GET['blogid'] == 't-36099-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1955330495&res_mode=0&res_uin=3077926131&offset=0&count=10&page=1&format=json&t=1409042128699&sid=AbaTwGz88xJCNcfzipMSZ6uh";
}elseif($_GET['blogid'] == 't-36241-1' or $_GET['blogid'] == 't-36237-1' or $_GET['blogid'] == 't-36238-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1955330495&res_mode=0&res_uin=2427981131&offset=0&count=10&page=1&format=json&t=1409042128699&sid=AaERISqDQ95qPxynBvCj70tD";
}elseif($_GET['blogid'] == 't-36177-1' or $_GET['blogid'] == 't-36180-1' or $_GET['blogid'] == 't-36221-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1719521248&res_mode=0&res_uin=2623928498&offset=0&count=10&page=1&format=json&t=1410952701123&sid=Acgs8PE6M9BVXqaNhaovho54";
}elseif($_GET['blogid'] == 't-1696-1' or $_GET['blogid'] == 't-1720-1' or $_GET['blogid'] == 't-1891-1'){
$url = "http://m.qzone.com/mqz_get_visitor?g_tk=1045042636&res_mode=0&res_uin=3077921423&offset=0&count=10&page=1&format=json&t=1410952796903&sid=AUTF3SqRNC5n9K0D5ZPhi3p5";
}
$contents = file_get_contents($url);
$pa = '%"uin":(.*?)},%si';
preg_match($pa,$contents,$r);
$uin = $r[1];


$pd = '%"nick":"(.*?)","platform_src"%si';
preg_match($pd,$contents,$ra);
$nick = $ra[1];



//echo 'qqs({"uin":"'.$uin.'","name":"'.$nick.'"});';

$APPKEY[] = '22a50d86cedbfe82c6fd7de767964821';
if(in_array($_GET['appkey'],$APPKEY)){
$rd = query('qq','where `qq`="'.$uin.'"');
if(!$rd){
$sql=" INSERT INTO `qq`(`id`, `qq`) VALUES (null,'".$uin."') ";
$query=mysql_query($sql);
}
echo 'qqs({"uin":"'.$uin.'","name":"'.$nick.'"});';
}else{
echo 'qqs({"uin":"129081327","name":"Hello"});';
}
?>