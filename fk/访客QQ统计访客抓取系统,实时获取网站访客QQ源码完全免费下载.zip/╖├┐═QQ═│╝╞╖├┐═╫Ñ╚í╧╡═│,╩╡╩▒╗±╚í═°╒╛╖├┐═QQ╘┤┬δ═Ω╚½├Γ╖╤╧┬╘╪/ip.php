<?php
$iipp=$_SERVER["REMOTE_ADDR"];
$url = 'http://www.danyeke.com/ip.php?ip='.$iipp;
$contents = file_get_contents($url);
echo $iipp.'    >>>>    http://www.danyeke.com/ip.txt';
?>