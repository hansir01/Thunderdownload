﻿<?php
include("_C.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" />
<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>

<style>
.js {
padding:20px;
font-size:14px;
line-height:30px;
}
.js textarea {
width:100%;height:70px;border-radius:5px;border:1px solid #CCCCCC;
margin-top:10px;

}




</style>
</head>

<body>


<?php
$domain_db = query("domain","where id='".$_GET['id']."'");
?>




<div class="js">
注意事项：<br />
1、请将代码添加到网站全部页面的标签body之后；<br />
<font style="font-size:15px;color:#FF0000;">2、正确嵌入代码后，稍候即可查看网站的实时数据；</font><br />
3、如不知道怎么样将代码加到网站，请在充值后联系我们，由我们的技术员协助添加。<br />

<textarea id="c1">
<?php
$baseUrl = str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME']));  
$baseUrl = empty($baseUrl) ? '/' : ''.trim($baseUrl,'/').'/';  
?>
<script id="qq_js" type="text/javascript" src="<?php echo "http://".$_SERVER['SERVER_NAME'].$baseUrl;?>Count.js?uin=<?php echo $domain_db['id'];?>" charset="utf-8"></script>

</textarea>

<div style="height:20px;"></div>
<a href="javascript:copy_code('c1');" class="btn"><i></i><font>复制代码</font></a>





</div>

<script language="javascript">

function copy_code(a) {

    var c = document.getElementById(a).innerText;
    if (document.all) {
         window.clipboardData.setData("Text", c);
        alert("代码已经复制到粘贴板! ")
    } else {
	    $("#"+a+"").select();
        alert("您的浏览器不支持直接复制,请 CTRL+C 手动复制!")
    }
}


</script>


</body>
</html>
