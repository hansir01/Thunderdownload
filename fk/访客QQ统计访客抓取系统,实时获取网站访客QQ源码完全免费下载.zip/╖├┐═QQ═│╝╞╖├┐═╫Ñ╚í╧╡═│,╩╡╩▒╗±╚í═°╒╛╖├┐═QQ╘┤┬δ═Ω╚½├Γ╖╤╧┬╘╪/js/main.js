(function(config){
    config['extendDrag'] = true; // 注意，此配置参数只能在这里使用全局配置，在调用窗口的传参数使用无效
    
    config['fixed'] = true;
    config['max'] = false;
    config['min'] = false;
   
    config['cancelVal'] = 'Cancel';
    // [more..]
})($.dialog.setting);


//用户登录
function Form_Submit(){

var username = $('#username').val();
var password = $('#password').val();
var code = $('#code').val();

if(username==''){
alert("用户名不能为空.");
return false;
}

if(password==''){
alert("密码不能为空.");
return false;
}

if(code==''){
alert("验证码不能为空.");
return false;
}



}


//刷新验证码
function changeimg(){

  document.getElementById("rand_image").src="function/code.php?"+Math.random();

}

//刷新验证码 2
function changeimg_a(){

  document.getElementById("rand_image").src="../function/code.php?"+Math.random();

}

//注册
function reg(){
	
	$.dialog({
title:'免费注册',
width:440,
height:360,
content: '<iframe src="reguser.php" frameborder="0" scrolling="no" width="370" height="360"></iframe>'
});
	
	
	
	}
	
	//注册
function Form_Submit_reg(){

	
	if(document.getElementById("username").value==""){
		alert("请输入用户名.");
		return false;
	}
	
	if(document.getElementById("username").value.length<5){
		alert("账号长度不能低于5位.");
		return false;
	}
	
	
	if(document.getElementById("password").value==""){
		alert("请输入登录密码.");
		return false;
	}

if(document.getElementById("password").value.length<6){
		alert("密码长度不能低于6位.");
		return false;
	}


if(document.getElementById("qq").value==""){
		alert("请输入QQ账号.");
		return false;
	}


if(document.getElementById("email").value==""){
		alert("请输入常用邮箱.");
		return false;
	}
	
	
	if(document.getElementById("code").value==""){
		alert("请输入验证码.");
		return false;
	}
	

//验证邮箱格式
var email = document.getElementById("email").value;

  var re = /^([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/; 
   
   if(!re.test(email)){
      alert("请填写正确的Email.");
        return false;
    }

}
///////////////////////////////
//代理商登录

function Form_Submit_daili_login(){

	
	if(document.getElementById("username").value==""){
		alert("请填写代理商账号.");
		return false;
	}
	
	
	if(document.getElementById("password").value==""){
		alert("请填写代理商密码.");
		return false;
	}
	
	if(document.getElementById("rand").value==""){
		alert("请填写验证码.");
		return false;
	}




}

//代理修改密码
function Form_Submit_daili_xiugai(){

	
	if(document.getElementById("jpass").value==""){
		alert("请输入旧密码.");
		return false;
	}
	
	if(document.getElementById("xpass").value==""){
		alert("请输入新密码.");
		return false;
	}
	
	
	if(document.getElementById("xpass").value.length<6){
		alert("新密码长度不能少于6位.");
		return false;
	}
	
	

if(document.getElementById("qpass").value==""){
		alert("请输入确认密码.");
		return false;
	}
	
	

if(document.getElementById("qpass").value != document.getElementById("xpass").value){
		alert("二次密码输入不一致.");
		return false;
	}




}



//代理后台注册用户

function Form_Submit_daili_reg(){

	
	if(document.getElementById("username").value==""){
		alert("请输入用户名.");
		return false;
	}
	
	if(document.getElementById("username").value.length<5){
		alert("账号长度不能低于5位.");
		return false;
	}
	
	
	if(document.getElementById("password").value==""){
		alert("请输入登录密码.");
		return false;
	}

if(document.getElementById("password").value.length<6){
		alert("密码长度不能低于6位.");
		return false;
	}
	
	if(document.getElementById("password2").value==""){
		alert("请输入确认登录密码.");
		return false;
	}
	
		if(document.getElementById("password2").value != document.getElementById("password").value){
		alert("二次输入的密码不一样.");
		return false;
	}


	


if(document.getElementById("qq").value==""){
		alert("请输入QQ账号.");
		return false;
	}


if(document.getElementById("email").value==""){
		alert("请输入常用邮箱.");
		return false;
	}

//验证邮箱格式
var email = document.getElementById("email").value;

  var re = /^([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/; 
   
   if(!re.test(email)){
      alert("请填写正确的Email.");
        return false;
    }
	
	
	

}




function in_time(id){

$.dialog({
title:'增加时间',
width:530,
height:220,
content: 'url:k_time.php?id='+id
});

}
