<?php
$site_name=empty($_GET['sn'])?'sample':$_GET['sn'];//if
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8" />
<title>智慧云服务器-中电云集-chinaccnet.com</title>
<link type="text/css" rel="stylesheet" href="asset/css/style.min.css" />
<script type="text/javascript" src="asset/js/jquery-1.8.2.min.js"></script>
<script type="text/javascript" src="asset/js/vm_client.min.js" ></script>
</head>

<body>

<div class="tabbed_content">
    <div class="tabs">
        <div class="moving_bg">&nbsp;</div>
        <span class="tab_item ftp" title="查看FTP密码">查看FTP密码</span>
        <span class="tab_item ftp_pass" title="重置FTP密码">重置FTP密码</span>
        <span class="tab_item mysql" title="查看MySQL密码">查看MySQL密码</span>
        <span class="tab_item mysql_pass tab_item_end" title="重置MySQL密码">重置MySQL密码</span>
        <div class="tab_front_bg"></div>
    </div>
    
    <div class="slide_content">						
        <div class="tabslider">
            <!-- 查看FTP密码 -->
            <div class="module bg_ftp">
            	<p class="op_check">您正在 <em>查看</em> 站点 <em><?php echo $site_name; ?></em> 的FTP密码</p>
                <form id="lookFTPPass" action="" method="post">
                    <p>
                        <label for="c_ftpAccount">FTP账号：</label>
                        <input type="text" id="c_ftpAccount" name="c_ftpAccount" maxlength="32" />
                    </p>
                    <p>
                        <label for="c_ftpOtp">动态口令：</label>
                        <input type="text" id="c_ftpOtp" name="c_ftpOtp" maxlength="6" />
                    </p>
                    <p>
                        <label for=""></label>
                        <input type="submit" value="查　看"/>
                    </p>
                </form>
            </div>
            <!-- 查看FTP密码 end -->
             
            <!-- 重置FTP密码 -->
            <div class="module bg_ftp">
            	<p class="op_setup">您正在 <em>重置</em> 站点 <em><?php echo $site_name; ?></em> 的FTP密码</p>
                <form id="setupFTPPass" action="" method="post">
                    <p>
                        <label for="s_ftpAccount">FTP账号：</label>
                        <input type="text" id="s_ftpAccount" name="s_ftpAccount" maxlength="32" />
                    </p>
                    <!--
                    <p>
                        <label for="s_ftpPass">新密码：</label>
                        <input type="password" id="s_ftpPass" name="s_ftpPass" maxlength="12" />
                    </p>
                    <p>
                        <label for="s_ftpConfirmPass">确认密码：</label>
                        <input type="password" id="s_ftpConfirmPass" name="s_ftpConfirmPass" maxlength="12" />
                    </p>
                    -->
                    <p>
                        <label for="s_ftpOtp">动态口令：</label>
                        <input type="text" id="s_ftpOtp" name="s_ftpOtp" maxlength="6" />
                    </p>
                    <p>
                        <label for=""></label>
                        <input type="submit" value="重　置"/>
                    </p>
                </form>
            </div>
            <!-- 重置FTP密码 end -->
           
            <!-- 查看MySQL密码 -->
            <div class="module bg_mysql">
            	<p class="op_check">您正在 <em>查看</em> 站点 <em><?php echo $site_name; ?></em> 的MySQL密码</p>
                <form id="lookMySQLPass" action="" method="post">
                    <p>
                        <label for="c_dbName">数据库名：</label>
                        <input type="text" id="c_dbName" name="c_dbName" maxlength="32" />
                    </p>
                    <p>
                        <label for="c_dbOtp">动态口令：</label>
                        <input type="text" id="c_dbOtp" name="c_dbOtp" maxlength="6" />
                    </p>
                    <p>
                        <label for=""></label>
                        <input type="submit" value="查　看"/>
                    </p>
                </form>
            </div>
            <!-- 查看MySQL密码 end -->
            
            <!-- 重置MySQL密码 -->
            <div class="module bg_mysql">
                <p class="op_setup">您正在 <em>重置</em> 站点 <em><?php echo $site_name; ?></em> 的MySQL密码</p>
                <form id="setupMySQLPass" action="" method="post">
                    <p>
                        <label for="s_dbName">数据库名：</label>
                        <input type="text" id="s_dbName" name="s_dbName" maxlength="32" />
                    </p>
                    <!--
                    <p>
                        <label for="s_dbPass">新密码：</label>
                        <input type="password" id="s_dbPass" name="s_dbPass" maxlength="16" />
                    </p>
                    <p>
                        <label for="s_dbConfirmPass">确认密码：</label>
                        <input type="password" id="s_dbConfirmPass" name="s_dbConfirmPass" maxlength="16" />
                    </p>
                    -->
                    <p>
                        <label for="s_dbOtp">动态口令：</label>
                        <input type="text" id="s_dbOtp" name="s_dbOtp" maxlength="6" />
                    </p>
                    <p>
                        <label for=""></label>
                        <input type="submit" value="重　置"/>
                    </p>
                </form>
            </div>
            <!-- 重置MySQL密码 end -->
           
        </div>
        <br style="clear:both;" />
    </div>
</div>


<div id="footer">
    <span>Copyright 2005-2014 <a href="http://www.chinaccnet.com/" target="_blank" title="中电云集">中电云集</a> <a href="http://www.miibeian.gov.cn/" target="_blank" title="浙B2-20100226-5">浙B2-20100226-5</a></span>
</div>

<div id="loading">
	<div id="loading_msg"></div>
</div>

<div id="alert">
	<div id="alert_title">
    	<span>提示：</span>
        <a id="btn_close" href="#" title="关闭"></a>
    </div>
    <div id="alert_content"></div>
    <div id="alert_operate">
    	<a id="btn_confirm" href="#" title="确定">确　定</a>
    </div>
</div>


</body>
</html>