﻿<?php
error_reporting(0);
session_start();
include("config.php");
include("function/function.php");
?>
<!doctype html>
<html>
 <head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>网站访客QQ获取</title>
<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
<script type="text/javascript" src="js/login.js"></script>
<link href="css/v3.css" rel="stylesheet" type="text/css" />
</head>
<body>
<h1>网站访客QQ获取<br /><a href="auth/example/oauth/index.php">点击使用QQ快捷登录</a></h1>
<div class="login">
  <div class="header">
    <div class="switch" id="switch"><a class="switch_btn_focus" id="switch_qlogin" href="javascript:void(0);" tabindex="7">快速登录</a> <a class="switch_btn" id="switch_login" href="javascript:void(0);" tabindex="8">快速注册</a>
      <div class="switch_bottom" id="switch_bottom" style="position: absolute; width: 54px; left: 0px;"></div>
    </div>
  </div>
  <div class="web_qr_login" id="web_qr_login" style="display: block; height: 225px;"> 
    <!--登录-->
    <div class="web_login" id="web_login">
      <div class="login-box">
        <div class="login_form">
          <form action="login.php" name="loginform" accept-charset="utf-8" id="login_form" class="loginForm" method="post">
            <input type="hidden" name="did" value="0"/>
            <input type="hidden" name="to" value="log"/>
            <div class="uinArea" id="uinArea">
              <label class="input-tips" for="u">帐号：</label>
              <div class="inputOuter" id="uArea">
                <input type="text" id="u" name="username" class="inputstyle"/>
              </div>
            </div>
            <div class="pwdArea" id="pwdArea">
              <label class="input-tips" for="p">密码：</label>
              <div class="inputOuter" id="pArea">
                <input type="password" id="p" name="password" class="inputstyle"/>
              </div>
            </div>
            <div style="padding-left:50px;margin-top:20px;">
              <input type="submit" name="submit" value="登 录" style="width:150px;" class="button_blue"/> 
            </div>
          </form>
        </div>
      </div>
    </div>
    <!--登录end--> 
  </div>
  
  
  <?php
if($_POST['submit']){
$username = trim($_POST['username']);
$password  = md5(trim($_POST['password']));

if(empty($username)){
skip("请输入用户名.","login.php");
exit();
}elseif(empty($password)){
skip("请输入登录密码.","login.php");
exit();
}



$db = query("users","where username='".$username."' and password = '".$password."'");
//密码错误
if(!is_numeric($db['id'])){
unset($_SESSION['username']);
unset($_SESSION['id']); 
skip("用户名或密码错误.","login.php");
exit();
}else{ //如正确
$_SESSION['username']=$db['username'];
$_SESSION['id']=$db['id'];
skip("","index.php");
}




}



?>
  
  
  
  <!--注册-->
  <div class="qlogin" id="qlogin" style="display: none; ">
    <div class="web_login">
      <form name="form2" id="regUser" accept-charset="utf-8"  action="reg.php" method="post" autocomplete = "off">
        <input type="hidden" name="to" value="reg"/>
        <input type="hidden" name="did" value="0"/>
        <ul class="reg_form" id="reg-ul">
        <div id="userCue" class="cue">快速注册请注意格式</div>
          <li>
            <label for="user"  class="input-tips2">用户名：</label>
            <div class="inputOuter2">
              <input type="text" id="user" name="username" maxlength="16" class="inputstyle2"/>
            </div>
          </li>
          <li>
            <label for="passwd" class="input-tips2">密码：</label>
            <div class="inputOuter2">
              <input type="password" id="passwd"  name="password" maxlength="16" class="inputstyle2"/>
            </div>
          </li>
          <li>
            <label for="qq" class="input-tips2">QQ：</label>
            <div class="inputOuter2">
              <input type="text" id="qq" name="qq" maxlength="10" class="inputstyle2"/>
            </div>
          </li>
          <li>
            <label for="passwd2" class="input-tips2">邮箱：</label>
            <div class="inputOuter2">
              <input type="text" id="email" name="email" maxlength="100" class="inputstyle2" />
            </div>
          </li>
        
          <li>
            <div class="inputArea">
              <input type="button" id="reg"  style="width:150px;margin-top:10px;margin-left:85px;" class="button_blue" value="注册"/>
			  </div>
          </li>
          <div class="cl"></div>
        </ul>
      </form>
    </div>
  </div>
  <!--注册end--> 
</div>
<div class="jianyi">*推荐使用ie8或以上版本ie浏览器或Chrome内核浏览器访问本站</div>

</body>
</html>