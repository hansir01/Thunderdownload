<?php 
header("content-type:text/html;charset=utf-8"); 
ini_set("magic_quotes_runtime",0); 
//获取邮件配置信息
require '../config.php';
require '../function/function.php';

//获取域名所属用户 UID
$uid_ = query("domain","where id='".$_GET['id']."'",1);
//根据 UID 查询用户
$user_a = query("users","where id='".$uid_['uid']."'");



//记录过期删除
$email_jilu = query("email_logs","where id<>''",0);
while($email_jilu_row = mysql_fetch_array($email_jilu)){

$jilu_time = strtotime(date("Y-m-d"));

if($jilu_time >= $email_jilu_row['outtime']){
del("email_logs","where id='".$email_jilu_row['id']."'");
}

}//




$email_sql=mysql_query("select * from domain where id='".$_GET['id']."'");
$email_row = mysql_fetch_array($email_sql);


//判断是否开启
if($email_row['email_state']=='0' || $email_row['id']==''){
exit("发送失败：您没有开启邮件推送功能");
}


//判断此QQ在本网站是否发送过推送邮件
$qq_sql=mysql_query("select * from email_logs where yid='".$_GET['id']."' and qq='".$_GET['qq']."'");
$qq_row = mysql_fetch_array($qq_sql);
if($qq_row['yid']!=''){
exit("邮件发送失败：".date("Y-m-d")." 此QQ今天已发送过邮件，请勿重复发送！");
}


//随机获取发送邮件端口

$sj_sql = query("email_user","where uid='".$user_a['id']."'",0);
while($sj_row = mysql_fetch_array($sj_sql)){

$sj[]=array($sj_row['smtp'],$sj_row['duankou'],$sj_row['user'],$sj_row['pass']);

}

$sj_count = count($sj)-1; //获取所有邮件smtp

$sj_rand = rand(0,$sj_count); //随机选用
//end


require 'class.phpmailer.php'; 
try { 
$mail = new PHPMailer(true); 
$mail->IsSMTP(); 
$mail->CharSet='UTF-8'; //设置邮件的字符编码，这很重要，不然中文乱码 
$mail->SMTPAuth = true; //开启认证 
$mail->Port = $sj[$sj_rand][1]; //端口 
$mail->Host = $sj[$sj_rand][0];  
$mail->Username = $sj[$sj_rand][2]; 
$mail->Password = $sj[$sj_rand][3]; 
//$mail->IsSendmail(); //如果没有sendmail组件就注释掉，否则出现“Could not execute: /var/qmail/bin/sendmail ”的错误提示 
$mail->AddReplyTo($sj[$sj_rand][2],$email_row['email_name']);//如果用户回复此邮件，则回复到本信箱 
$mail->From = $sj[$sj_rand][2]; //发件人的地址
$mail->FromName = $email_row['email_name']; //发件人名称
//标题
$content_t = str_replace("[qq]",$_GET['qq'],$email_row['email_title']);
$content_t = str_replace("[time]",date("Y-m-d H:i:s"),$content_t);
$content_t = str_replace("[name]",$_GET['name'],$content_t);
$content_t = str_replace("[url]",$_GET['url'],$content_t);

//内容
$content_c = str_replace("[qq]",$_GET['qq'],$email_row['email_content']);
$content_c = str_replace("[time]",date("Y-m-d H:i:s"),$content_c);
$content_c = str_replace("[name]",$_GET['name'],$content_c);
$content_c = str_replace("[url]",$_GET['url'],$content_c);

$to = $_GET['qq']."@qq.com"; //收件人的地址
$mail->AddAddress($to); 
$mail->Subject = $content_t;  //标题
$mail->Body = $content_c." 【本邮件由系统自动发送，请勿回复】";  //内容
$mail->AltBody = "To view the message, please use an HTML compatible email viewer!"; //当邮件不支持html时备用显示，可以省略 
$mail->WordWrap = 80; // 设置每行字符串的长度 
//$mail->AddAttachment("f:/test.png"); //可以添加附件 
$mail->IsHTML(true); 
$mail->Send(); 
echo '邮件发送成功：'.date("Y-m-d"); 

//给此QQ发送过邮件，产生记录
$del_time = strtotime(date("Y-m-d",strtotime('+1 day')));

$arr_qq = array(
'',
$_GET['id'],
$_GET['qq'],
$del_time
);
insert("email_logs",$arr_qq);


} catch (phpmailerException $e) { 
echo "邮件发送失败：".$e->errorMessage()."邮件账号或密码错误，请检查！"; 
} 

?> 
