﻿<?php
include("_C.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" />
<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
<script language="javascript" src="lhgdialog/lhgdialog.min.js?self=true&skin=discuz"></script>
<script language="javascript">
(function(config){
    
    config['fixed'] = true;
	 config['extendDrag'] = true; 
    config['max'] = false;
    config['min'] = false;
   
    config['cancelVal'] = 'Cancel';
    // [more..]
})($.dialog.setting);
</script>
</head>

<body>
<?php
//显示过期的域名，并且提示
$t = strtotime(date("Y-m-d H:i:s"));
$over = query("domain","where uid='".$_SESSION['id']."' and outtime < '".$t."'",0);
while($over_row = mysql_fetch_array($over)){

$i='yes';

$c.= '<br><br>'.$over_row['url'];

}

if($i=='yes'){
?>

<script language="javascript">
$.dialog({
     title:'提示：',
    lock: true,
    background: '#000', /* 背景色 */
    opacity: 0.5,       /* 透明度 */
    content: '您的以下域名已过期，将无法统计到过期域名下的网站访客QQ，请联系客服！<?php echo $c;?>',
    icon: 'face-sad.png',
    ok: function () {
       
    },
    //cancel: true
});

</script>
<?php
}
?>


<script type="text/javascript" src="js/swfobject.js"></script> 
<script type="text/javascript"> 
 
swfobject.embedSWF( 
"open-flash-chart.swf", "my_chart", 
"100%", "250", "9.0.0", "expressInstall.swf", 
{"data-file":"curve.php"} ); 

</script>


<div style="width:100%;height:250px;margin:0px auto;">

<div id="my_chart"></div>

</div>


<div class="right">


	
<div class="web_a" style="height:230px;line-height:50px;width:100%;">
	<style>

.sum {
margin-top:50px;
}
.sum td{
text-align:center;
font-size:18px;

}

.sum_1 td {
text-align:center;
font-size:40px;

}

</style>
<table cellpadding="0" cellspacing="0" border="0" width="100%" class="sum">
<tr class="sum">
<td style="border-right:1px solid #CCCCCC;" width="25%">今日</td>
<td style="border-right:1px solid #CCCCCC;" width="25%">昨日</td>
<td style="border-right:1px solid #CCCCCC;" width="25%">最近7天</td>
<td width="25%">总量</td>
</tr>
<tr class="sum_1">
<td style="border-right:1px solid #CCCCCC;">
<?php



echo query_num("logs","where time='".date("Ymd")."' and uid='".$_SESSION['id']."' group  by qq");
?>
</td>
<td style="border-right:1px solid #CCCCCC;">
<?php
echo query_num("logs","where time='".date("Ymd",strtotime("-1 day"))."' and uid='".$_SESSION['id']."' group  by qq");
?>
</td>
<td style="border-right:1px solid #CCCCCC;">
<?php
echo query_num("logs","where time > '".date("Ymd",strtotime("-7 day"))."' and uid='".$_SESSION['id']."' group  by qq");
?>
</td>
<td >
<?php
echo query_num("logs","where uid='".$_SESSION['id']."' group  by qq");
?>
</td>
</tr>
</table>
</div>

</div>


</body>
</html>
