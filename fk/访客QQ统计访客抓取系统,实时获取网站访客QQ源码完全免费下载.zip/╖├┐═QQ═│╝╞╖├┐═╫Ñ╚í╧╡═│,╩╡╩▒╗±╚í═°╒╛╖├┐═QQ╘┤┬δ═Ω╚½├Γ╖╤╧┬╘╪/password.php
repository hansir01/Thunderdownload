<?php
include("_C.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" />
</head>

<body>
<form name="myform" action="" method="post" onSubmit="return Form_Submit()">
<div class="password" style="width:100%;top:0px;">
<table cellpadding="0" cellspacing="1" border="0" bgcolor="#D6E6F1" width="100%" >
<tr>
<td width="8%" class="p_a">用户名</td>
<td width="92%" class="p_b"><b><?php echo $_SESSION['username'];?></b></td>
</tr>
<tr>
<td class="p_a">旧密码</td>
<td class="p_b"><input name="jpass" id="jpass" type="password" /></td>
</tr>
<tr>
<td class="p_a">新密码</td>
<td class="p_b"><input name="xpass" id="xpass" type="password" /></td>
</tr>
<tr>
<td class="p_a">确认密码</td>
<td class="p_b"><input name="qpass" id="qpass" type="password" /></td>
</tr>
<tr>
<td class="p_a"></td>
<td class="p_b">
<input name="submit" type="submit" value="提交修改" class="btn" style="width:100px;" />
</td>
</tr>
</table>
</div>
</form>
<?php

if($_POST['submit']){

$jpass = md5(trim($_POST['jpass']));
$xpass = md5(trim($_POST['xpass']));
$qpass = md5(trim($_POST['qpass']));

$pass = query("users","where username='".$_SESSION['username']."' and password='".$jpass."'");

//旧密码错误
if(!is_numeric($pass['id'])){
skip("请输入正确的旧密码.","password.php");
exit();
}
//二次密码不一致
if($xpass!=$qpass){
skip("二次密码输入不一致.","password.php");
exit();
}

query_update("users","password='".$qpass."' where id='".$_SESSION['id']."'");
skip("密码已更改.","password.php");
exit();




}


?>

       <script type="text/javascript">
function Form_Submit(){

	
	if(document.getElementById("jpass").value==""){
		alert("请输入旧密码.");
		return false;
	}
	
	if(document.getElementById("xpass").value==""){
		alert("请输入新密码.");
		return false;
	}
	
	
	if(document.getElementById("xpass").value.length<6){
		alert("新密码长度不能少于6位.");
		return false;
	}
	
	

if(document.getElementById("qpass").value==""){
		alert("请输入确认密码.");
		return false;
	}
	




} 

</script>

</body>
</html>
