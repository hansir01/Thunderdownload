<?php
echo 1;
?>