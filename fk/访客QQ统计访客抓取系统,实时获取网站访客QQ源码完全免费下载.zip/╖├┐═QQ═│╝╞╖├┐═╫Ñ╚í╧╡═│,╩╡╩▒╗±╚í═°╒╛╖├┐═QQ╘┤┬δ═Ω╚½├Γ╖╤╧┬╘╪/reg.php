﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>

<body>
<?php
include("config.php");
include("function/function.php");

$username = trim($_POST['username']);
$password  = md5(trim($_POST['password']));
$qq = trim($_POST['qq']);
$email = trim($_POST['email']);
$tel = trim($_POST['tel']);

if(empty($username)){
skip("请输入用户名.","login.php");
exit();
}elseif(empty($password)){
skip("请输入登录密码.","login.php");
exit();
}elseif(empty($qq)){
skip("请输入QQ号码.","login.php");
exit();
}elseif(empty($qq)){
skip("请输入邮箱账号.","login.php");
exit();
}

//用户名重名判断
$db = query("users","where username='".$username."'");
if(is_numeric($db['id'])){
skip("用户名已存在.","login.php");
exit();
}else{ //执行添加

$arr = array(
'',
$_GET['proxy'],
$username,
$password,
strtotime(date("Y-m-d H:i:s")),
strtotime(date("Y-m-d H:i:s")),
$qq,
$email,
$tel,
'',
);
insert("users",$arr);
skip("恭喜您已注册，请返回登录.","login.php");
exit();


}




?>

</body>
</html>
