﻿<?php
include("_C.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" />
<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
</head>

<body>

<div class="right" >

<?php
$name = query("domain","where id='".$_GET['domain']."'");
?>
<div style="width:100%;">


<div class="right_a" style="width:100%;height:40px;line-height:40px;">

<font style="float:left;">&nbsp;&nbsp;&nbsp;网站：
<select onchange="mbar_a(this);" style="background:#85D5B2;color:#000000;">
<?php
$db = query("domain","where uid='".$_SESSION['id']."'",0);
while($db_row=mysql_fetch_array($db)){
?>
<option value="right.php?domain=<?php echo $db_row['id'];?>" <?php $_GET['domain']==$db_row['id'] ? print 'selected':FALSE; ?>><?php echo $db_row['url'];?></option>
<?php
}
?>
</select>
<SCRIPT language=javascript>
<!--
// open the related site windows
function mbar_a(sobj) {
var docurl =sobj.options[sobj.selectedIndex].value;
if (docurl != "") {
   open(docurl,'_self');
   sobj.selectedIndex=0;
   sobj.blur();
}
}
//-->
</SCRIPT>
</font>
<font style="float:left;">&nbsp;&nbsp;&nbsp;访问时间：</font>
<a href="?domain=<?php echo $_GET['domain'];?>" <?php $_GET['time']=='' ? print 'style="background:#85D5B2;color:#FFFFFF;"' :FALSE;?>>全部</a>
<a href="?time=j&domain=<?php echo $_GET['domain'];?>" <?php $_GET['time']=='j' ? print 'style="background:#85D5B2;color:#FFFFFF;"' :FALSE;?>>今天</a>
<a href="?time=z&domain=<?php echo $_GET['domain'];?>" <?php $_GET['time']=='z' ? print 'style="background:#85D5B2;color:#FFFFFF;"' :FALSE;?>>昨天</a>
<a href="?time=week&domain=<?php echo $_GET['domain'];?>" <?php $_GET['time']=='week' ? print 'style="background:#85D5B2;color:#FFFFFF;"' :FALSE;?>>本周</a>
<a href="?time=yue&domain=<?php echo $_GET['domain'];?>" <?php $_GET['time']=='yue' ? print 'style="background:#85D5B2;color:#FFFFFF;"' :FALSE;?>>本月</a>
<a href="?time=nian&domain=<?php echo $_GET['domain'];?>" <?php $_GET['time']=='nian' ? print 'style="background:#85D5B2;color:#FFFFFF;"' :FALSE;?>>本年</a>


<a class="btn" style="margin-top:5px;" href="txt.php?time=<?php echo $_GET['time'];?>&domain=<?php echo $_GET['domain'];?>&fenlei=<?php echo $_GET['fenlei'];?>&action=excel" onclick="JavaScript:return confirm('确认导出当前条件的所有记录吗？')" ><font>导出TXT数据</font></a>

<a class="btn" style="margin-top:5px;" href="excel.php?time=<?php echo $_GET['time'];?>&domain=<?php echo $_GET['domain'];?>&fenlei=<?php echo $_GET['fenlei'];?>&action=excel" onclick="JavaScript:return confirm('确认导出当前条件的所有记录吗？')" ><font>导出Excel数据</font></a>




</div>
</div>

<table cellpadding="0" cellspacing="1" border="0" bgcolor="#D6E6F1" width="100%" >
<tr class="qqlist">

<td>访问时间</td>
<td>首访时间</td>
<td>昵称</td>
<td>QQ号码</td>
<td>分类</td>
<td>来路</td>
<td>关键词</td>
<td>入口页</td>
<td>最后停留页</td>
<td>IP</td>
<td>来源地区</td>
<td>页数</td>
<td>时长</td>

</tr>
<?php

$week = date('Ymd',(time()-((date('w')==0?7:date('w'))-1)*86400)); //本周一
$week_a = date('Ymd',(time()+(7-(date('w')==0?7:date('w')))*86400)); //本周日
$yue = date('Ymd',strtotime(date('Y-m', time()).'-01 00:00:00')); //本月第一天
$yue_a = date('Ymd',strtotime(date('Y-m', time()).'-'.date('t', time()).' 00:00:00')); //本月最后一天
//查询条件

if(is_numeric($_GET['domain'])){ //域名ID
$where = " and yid='".$_GET['domain']."'";
}

if($_GET['time']=='j'){  //今天
$where.= " and time='".date("Ymd")."'";
}

if($_GET['time']=='z'){  //昨天
$where.= " and time='".date("Ymd",strtotime('-1 day'))."'";
}

if($_GET['time']=='week'){  //本周
$where.= " and time >='".$week."' and time <= '".$week_a."'";
}

if($_GET['time']=='yue'){  //本月
$where.= " and time >='".$yue."' and time <= '".$yue_a."'";
}

if($_GET['time']=='nian'){  //本年
$nian = date("Y");
$where.= " and time like  '$nian%'";
}

###分类

if($_GET['fenlei']!=''){  
$where.= " and state ='".$_GET['fenlei']."'";
}




//查询信息总的条数
$db_num_sql=mysql_query("select *, qq from logs where uid='".$_SESSION['id']."' $where group by qq order by id desc");	
$db_num = mysql_num_rows($db_num_sql);
//每页显示的条数  
  $page_size=10;  
//总条目数  
  $nums=$db_num;  
//每次显示的页数  
  $sub_pages=10;  
//得到当前是第几页  
 $pageCurrent=$_GET['pn']; 

if(!$pageCurrent) $pageCurrent=1;  
 
$page_num=$pageCurrent-1;
$page_num=$page_num*$page_size;



$list_sql = mysql_query('SELECT * FROM (SELECT * FROM `logs` where uid='.$_SESSION['id'].$where.' ORDER BY `id` DESC ) t GROUP BY `qq` ORDER BY `id` DESC LIMIT ' .$page_num.',' . $page_size);


while($value=mysql_fetch_array($list_sql)){
$value_data = unserialize($value['data']);

?>

<tr class="qqlist_a">

<td style="position:relative;">


<?php
if(date("Y-m-d",$value_data['time']) == date("Y-m-d") ){
echo date("H:i:s",$value_data['time']);
}else{
echo date("m-d H:i:s",$value_data['time']);
}
?>
</td>
<td>
<?php
$s_date = query("logs","where qq='".$value['qq']."' and yid='".$_GET['domain']."' order by id asc",1);
$s_date = unserialize($s_date['data']);

if(date("Y-m-d",$s_date['time']) == date("Y-m-d") ){
echo date("H:i:s",$s_date['time']);
}else{
echo date("m-d H:i:s",$s_date['time']);
}


?>
</td>
<td><font title="<?php echo $value_data['name'];?>"><?php echo mysubstr($value_data['name'],0,8);?></font></td>
<td>
<?php echo $value['qq'];?>
 <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $value['qq'];?>&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:<?php echo $value['qq'];?>:52" alt="点击这里给我发消息" title="点击这里给我发消息"/></a>
</td>

<td>
<SCRIPT language=javascript>
<!--
// open the related site windows
function mbar(sobj) {
var docurl =sobj.options[sobj.selectedIndex].value;
if (docurl != "") {
   open(docurl,'_self');
   sobj.selectedIndex=0;
   sobj.blur();
}
}
//-->
</SCRIPT>
<select onchange="mbar(this);" name="select">
<option value="?qq=<?php echo $value['qq'];?>&action=fenlei&value=1&domain=<?php echo $_GET['domain'];?>" <?php $value['state']==1 ? print 'selected' :FALSE;?>>未联系</option>
<option value="?qq=<?php echo $value['qq'];?>&action=fenlei&value=2&domain=<?php echo $_GET['domain'];?>" <?php $value['state']==2 ? print 'selected' :FALSE;?>>已联系</option>
<option value="?qq=<?php echo $value['qq'];?>&action=fenlei&value=3&domain=<?php echo $_GET['domain'];?>" <?php $value['state']==3 ? print 'selected' :FALSE;?>>已成交</option>
<option value="?qq=<?php echo $value['qq'];?>&action=fenlei&value=4&domain=<?php echo $_GET['domain'];?>" <?php $value['state']==4 ? print 'selected' :FALSE;?>>无效</option>
</select>
</td>

<td><a target="_blank" href="<?php echo $value_data['llurl'];?>" title="<?php echo $value_data['llurl'];?>"><?php echo mysubstr($value_data['llurl'],0,15);?></a></td>
<td><font title="<?php echo $value_data['word'];?>"><?php echo mysubstr($value_data['word'],0,12);?></font></td>
<td>
<?php
 $cpage_date = query("logs","where qq='".$value['qq']."' and yid='".$_GET['domain']."' order by id asc",1);
 $cpage_date = unserialize($cpage_date['data']);
 ?>
 <a target="_blank" href="<?php echo $cpage_date['rpage'];?>" title="<?php echo $cpage_date['rpage'];?>">
 <?php echo mysubstr($cpage_date['rpage'],0,15);?>
 </a>
</td>
<td>
<a target="_blank" href="<?php echo $value_data['rpage'];?>" title="<?php echo $value_data['rpage'];?>"><?php echo mysubstr($value_data['rpage'],0,15);?></a>
 </td>
<td><?php echo $value_data['ip'];?></td>
<td><font title="<?php echo $value_data['ip_city'];?>"><?php echo mysubstr($value_data['ip_city'],0,12);?></font></td>
<td>
<?php
echo query_num("logs","where qq='".$value['qq']."' and yid='".$_GET['domain']."'");
?>
</td>
<td><?php 

$value_data['miao'] <= 15 ? print "<0'15" : false;
$value_data['miao'] > 15 and $value_data['miao'] < 60 ? print "0'".$value_data['miao'] : false;

if($value_data['miao'] > 59 ){

$miao = $value_data['miao']/60;
$miao = round($miao,1);
echo str_replace(".","'",$miao);
}


?></td>

</tr>

<?php

}


?>

</table>

<div class="page">
共有 <?php echo $db_num;?> 条数据，<?php
$subPages=new SubPages($page_size,$nums,$pageCurrent,$sub_pages,"?domain=$_GET[domain]&time=$_GET[time]&pn=",2); 


##更改分类

if($_GET['action']=='fenlei'){

query_update("logs","state='".$_GET['value']."' where uid='".$_SESSION['id']."' and yid='".$_GET['domain']."' and qq='".$_GET['qq']."'");
skip("","right.php?domain=".$_GET['domain']);

}

?>
</div>


</div>

</body>
</html>
