﻿<?php
include("_C.php");
?>
<!doctype html>
<html>
 <head>
  <meta charset="UTF-8" />
  <title></title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="stylesheet" href="css/profile.css" />
  <!--[if lt IE 7]>
       <link rel="stylesheet" href="css/font-awesome-ie7.min.css" />
  <![endif]-->
  <script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
  <script type="text/javascript">
	$(document).ready(function(){
		$('.gh-nav a').click(function(){
			$('.gh-nav a').removeClass('active');
			$(this).addClass('active');
		});
	});
  </script>
</head>
<body>
<?php

if($_GET['action']=='quit'){
unset($_SESSION['username']);
unset($_SESSION['id']); 
skip("","login.php","top");
exit();
}

$db = query("users","where id='".$_SESSION['id']."'");

$top_domain = query("domain","where uid='".$_SESSION['id']."' order by id asc");
?>
   <div class="gh-top">
	<a href="main.php" class="logo fl" style="color:#fff;font-weight:bold;" target="mainFrame">网站访客统计系统</a>
	<div class="gh-nav fl">
		<a class="active" href="main.php" style="color:#E7F2FB;" target="mainFrame">首页</a>
		<a href="right.php?domain=<?php echo $top_domain['id'];?>" style="color:#E7F2FB;" target="mainFrame">访客列表</a>
		<a style="color:#E7F2FB;" href="weblist.php" target="mainFrame">站点列表</a>
		<a style="color:#E7F2FB;" href="email_list.php" target="mainFrame">发件箱管理</a>
		<a style="color:#E7F2FB;" href="password.php" target="mainFrame">修改密码</a>
	</div>
	<div class="dropdown fr" style="margin: 10px 10px;color:#E7F2FB;padding-right:20px;">
			Hi~ <?php echo $_SESSION['username'];?> [ <a href="?action=quit" onClick="JavaScript:return confirm('确认退出系统吗？')"><font style="color:#E7F2FB;">退出</font></a> ]</div>
</div>
</body>
</html>