<?php
include("function/session.php");
include("config.php");
include("function/function.php");


$week = date('Ymd',(time()-((date('w')==0?7:date('w'))-1)*86400)); //本周一
$week_a = date('Ymd',(time()+(7-(date('w')==0?7:date('w')))*86400)); //本周日
$yue = date('Ymd',strtotime(date('Y-m', time()).'-01 00:00:00')); //本月第一天
$yue_a = date('Ymd',strtotime(date('Y-m', time()).'-'.date('t', time()).' 00:00:00')); //本月最后一天
//查询条件

if(is_numeric($_GET['domain'])){ //域名ID
$where = " and yid='".$_GET['domain']."'";
}

if($_GET['time']=='j'){  //今天
$where.= " and time='".date("Ymd")."'";
}

if($_GET['time']=='z'){  //昨天
$where.= " and time='".date("Ymd",strtotime('-1 day'))."'";
}

if($_GET['time']=='week'){  //本周
$where.= " and time >='".$week."' and time <= '".$week_a."'";
}

if($_GET['time']=='yue'){  //本月
$where.= " and time >='".$yue."' and time <= '".$yue_a."'";
}

if($_GET['time']=='nian'){  //本年
$nian = date("Y");
$where.= " and time like  '$nian%'";
}


###分类

if($_GET['fenlei']!=''){  
$where.= " and state ='".$_GET['fenlei']."'";
}



//查询信息总的条数
$db_num_sql=mysql_query("select *, qq from logs where uid='".$_SESSION['id']."' $where group by qq order by id desc");	
$db_num = mysql_num_rows($db_num_sql);

if($db_num < '1'){
skip("没有记录可供导出.","right.php?time=".$_GET['time']."&domain=".$_GET['domain']."&fenlei=".$_GET['fenlei']."");
exit();
}




$list_sql = mysql_query('SELECT * FROM (SELECT * FROM `logs` where uid='.$_SESSION['id'].$where.' ORDER BY `id` DESC ) t GROUP BY `qq` ORDER BY `id` DESC');

$ina=2;

while($value=mysql_fetch_array($list_sql)){
$value_data = unserialize($value['data']);
//访问时间
if(date("Y-m-d",$value_data['time']) == date("Y-m-d") ){
$fangwen_time = date("H:i:s",$value_data['time']);
}else{
$fangwen_time = date("m-d H:i:s",$value_data['time']);
}
//首访时间
$s_date = query("logs","where qq='".$value['qq']."' order by id asc",1);
$s_date = unserialize($s_date['data']);

if(date("Y-m-d",$s_date['time']) == date("Y-m-d") ){
$shoufang_time = date("H:i:s",$s_date['time']);
}else{
$shoufang_time = date("m-d H:i:s",$s_date['time']);
}
//入口页
 $cpage_date = query("logs","where qq='".$value['qq']."' order by id asc",1);
 $cpage_date = unserialize($cpage_date['data']);

$i = $ina++;
ob_clean();//清理excel内容之间的缓冲区，否则导出内容乱码

$str.=$value['qq']."\r\n";



}

//============================================= SQL END ============================

$filename = date("Y-m-d H:i:s");
header("Content-type: text/plain");
header("Accept-Ranges: bytes");
header("Content-Disposition: attachment; filename=".$filename);
header("Cache-Control: must-revalidate, post-check=0, pre-check=0" );
header("Pragma: no-cache" );
header("Expires: 0" ); 
exit($str);
?>