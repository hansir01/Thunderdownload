﻿<?php
include("_C.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/css.css" media="screen" />
<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
<script language="javascript" src="lhgdialog/lhgdialog.min.js?self=true&skin=discuz"></script>
<script language="javascript">
(function(config){
    
    config['fixed'] = true;
	 config['extendDrag'] = true; 
    config['max'] = false;
    config['min'] = false;
   
    config['cancelVal'] = 'Cancel';
    // [more..]
})($.dialog.setting);
</script>

</head>

<body>

<?php
///////////////////////////////////判断网站授权时间是否到期
$state_db = query("domain","where uid='".$_SESSION['id']."'",0);
while($row_state = mysql_fetch_array($state_db)){

if( strtotime(date("Y-m-d H:i:s")) > $row_state['outtime'] ){
query_update("domain","state=2 where id='".$row_state['id']."'");
}



}
?>



<div class="right" >


<div class="web_a" style="width:100%;">

<div style="text-align:center;margin-top:20px;">
<form name="myform" action="" method="post" onSubmit="return Form_Submit()">
<font style="color:#000000;font-weight:bold;font-size:20px;">http:// </font><input name="url" id="url" type="text" class="web_input" placeholder="请输入你的域名或二级域名，如：www.baidu.com"  /><input name="submit" type="submit" value="添加站点" class="web_sub" />
</form>
</div>


</div>

<table cellpadding="0" cellspacing="1" border="0" bgcolor="#D6E6F1" width="100%" style="margin:0px auto;" >
<tr class="qqlist">

<td width="54">序号</td>

<td width="597" style="text-align:left;padding-left:5px;">站点URL</td>
<td width="115">开通状态</td>
<td width="115">剩余时间</td>
<td width="115">邮件推送</td>
<td width="115">安装代码</td>
<td width="115">操作</td>
</tr>
<?php
$i=1;
$db = query("domain","where uid='".$_SESSION['id']."'",0);
while($db_row = mysql_fetch_array($db)){
?>

<tr class="qqlist_a">
<td><?php echo $i++;?></td>

<td style="text-align:left;padding-left:5px;">http://<?php echo $db_row['url'];?></td>
<td>
<?php
if($db_row['state']=='0'){
echo '试用中...';
}
?>

<?php
if($db_row['state']=='1'){
echo '已开通';
}
?>

<?php
if($db_row['state']=='2'){
echo '已过期';
}
?>
</td>
<td>
<?php
$daoqi_time = timediff(strtotime(date("Y-m-d H:i:s")),$db_row['outtime']);
if( strtotime(date("Y-m-d H:i:s")) > $db_row['outtime'] ){
echo '已到期';
}else{
echo $daoqi_time['day']."天".$daoqi_time['hour']."小时".$daoqi_time['min']."分";
}
?>
</td>

<td>
<a  href="email.php?id=<?php echo $db_row['id'];?>">设置</a>
<a style="display:none;" href="javascript:;" onclick="email_shezhi(<?php echo $db_row['id'];?>)">设置</a>
<?php
if($db_row['email_state']=='0'){
echo ' （已关闭）';
}else{
echo ' <font style="color:#FF0000;">（已开启）</font>';
}
?>

</td>
<td><a href="javascript:;" onclick="js(<?php echo $db_row['id'];?>)">获取代码</a></td>
<td style="padding-top:3px;padding-bottom:3px;">

<?php
if( strtotime(date("Y-m-d H:i:s")) > $db_row['outtime'] ){
?>
<a href="?id=<?php echo $db_row['id'];?>&action=del" onclick="JavaScript:return confirm('是否确定删除 <?php echo $db_row['url'];?>？\n　　请慎重操作，删除 <?php echo $db_row['url'];?> 后该网站的所有数据将会全部删除，并且不能恢复！\n　　是否继续删除操作？')" class="btn"><i class="icon-trash"></i><font>删除站点</font></a>
<?php
}else{
?>
<a href="javascript:;" onclick="alert('时间未过期，您无权限删除！')" class="btn"><font style="color:#CCCCCC;text-decoration:line-through;">删除站点</font></a></font>
<?php
}
?>



</td>
</tr>
<?php
}
?>
</table>

</div>

<?php
if($_POST['submit']){
$url = str_replace("http://","",$_POST['url']);
//////////////////////////////////////////////////////////////////判断重复
$url_cf = query_num("domain","where url='".$url."' and uid='".$_SESSION['id']."'");
if($url_cf == 1){
skip("添加网站失败，请不要重复添加！","weblist.php");
exit();
}
/////////////////////////////////////////////////////////////////添加域名
$arr = array(
'',
$_SESSION['id'],
$url,
'0',
strtotime(date("Y-m-d H:i:s",strtotime("+2 hours"))),
strtotime(date("Y-m-d H:i:s")),
0,
'',
'',
''
);
insert("domain",$arr);

skip("","weblist.php");
}
/////////////////////////////////////////////////////////////////删除域名
if(is_numeric($_GET['id']) && $_GET['action']=='del'){
del("domain","where id='".$_GET['id']."' and uid='".$_SESSION['id']."'");
del("logs","where yid='".$_GET['id']."' and uid='".$_SESSION['id']."'");

skip("","weblist.php");
}

?>

 <script type="text/javascript">
function Form_Submit(){

	
	var url = document.getElementById("url").value;
	var url = "http://"+url;
	 regExp = /(http[s]?|ftp):\/\/[^\/\.]+?\..+\w$/i;
        if (url.match(regExp)){
		
		}else{
		alert('请输入正确网址.');
		return false;
		}
	


} 





function email_shezhi(id){

$.dialog({
title:'邮件推送设置',
width:630,
height:520,
content: 'url:email.php?id='+id
});

}


function js(id){

$.dialog({
title:'安装与设置',
width:690,
height:330,
content: 'url:js.php?id='+id
});

}
</script>




</body>
</html>
